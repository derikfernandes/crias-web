import { StrictMode } from 'react'
import { createRoot } from 'react-dom/client'
import './design/styles/index.css'
import App from './App.tsx'
import { bindFullscreen } from './lib/fullscreen'

bindFullscreen()

createRoot(document.getElementById('root')!).render(
  <StrictMode>
    <App />
  </StrictMode>,
)
