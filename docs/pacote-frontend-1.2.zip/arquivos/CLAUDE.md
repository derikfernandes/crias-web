# Regras do projeto Crias (redesign)

## Base atual: v1.1 (fechada em 16/10/2026)

- Versões: **v1.1** é a versão atual, fechada em 16/10/2026 (`Crias Aluno v1.1.dc.html` e `Crias Gestao v1.1.dc.html`). **v1.0** é a base anterior (`Crias Aluno v1.0.dc.html` e `Crias Painel v1.0.dc.html`). Não existe v1.1. Nada muda sem pedido explícito. No repositório: `frontend/crias-aluno/design/prototipo/Crias Aluno.dc.html` e `Crias Gestao.dc.html`. Versões e telas antigas ficam em `historico/`.
- Pacote 1.1.1.b: a fonte única é INTERFACE.md, seção "Pacote 1.1.1.b: regras consolidadas" (identidade, botões, Voltar, confirmações, ações em massa, salvar e sair, páginas, celular, pontos para validação).
- As regras completas estão em `INTERFACE.md`, seções "Base v1.1: fechamento" (1.1.27 a 1.1.38), "Base v1.1: primeira parte" (1.1.1 a 1.1.26) e "Base v1.0 travada". Onde houver conflito, vale o fechamento, depois a primeira parte, depois a v1.0.

## Pacotes v1.1.1

- **1.1.1.a**: correções recentes (INTERFACE.md, "Correções v1.1.1.a", 1.1.39 a 1.1.41).
- **1.1.1.b**: melhorias em andamento no Aluno e na Gestão. Toda alteração nova é registrada como 1.1.1.b.N em INTERFACE.md, seção "Melhorias v1.1.1.b".
- **1.1.1.b (24/10/2026)**: `Crias Aluno v1.1.1b.dc.html` e `Crias Gestao v1.1.1b.dc.html`. A Gestão 1.1.1.b é o antigo estudo Redesign aprovado (menu no topo e padrões das revisões 1 a 5 em INTERFACE.md, "Gestão 1.1.1.b (antes Redesign)"); substitui a Gestão 1.1.1.b de 23/10. A v1.1 oficial segue intacta.
- O pacote 1.1.1.b é exportado sozinho; o Claude Code junta 1.1.1.a e 1.1.1.b para formar a v1.1.1.

## Repositório e escopo

- Repositório: thiagocrias/crias-web, branch main. Versões do frontend: v0 (original), v1.0 (já no repositório) e v1.1 (atual).
- Apps: frontend/crias-aluno e frontend/crias-gestao. O design (INTERFACE.md, DECISOES.md, LEIA-ME.md, design-system/, prototipo/) fica em frontend/crias-aluno/design/.
- Só camada visual: estilos e JSX de apresentação. Lógica, API, estado e navegação não mudam. Itens que exigem lógica estão marcados como CONFLITO em INTERFACE.md.
- Pacote de entrega: export/repo/ espelha a raiz do repositório. Atualizar sempre que o protótipo ou INTERFACE.md mudarem. No pacote, os arquivos do protótipo perdem o sufixo de versão (os links internos são ajustados) e há uma versão offline de cada um.

## Texto e vocabulário

- Português do Brasil. Nunca usar travessão (—) nem "–" em textos de interface.
- Nunca usar a palavra "Passo" na interface. Sempre "Etapa" (ex.: "Etapa 3 de 12"). Exercícios sempre "exercício" (ex.: "Responda o exercício").
- Ausência de dado: "N/A" (campo vazio, telefone, % sem base, vínculo inexistente), em todo o Crias.
- Vocabulário banco para interface: tutor = monitor, trail = trilha, question = atividade, stage = etapa. Hierarquia: trilha > atividade > etapa (banco: trails > question > stage). Conclusão no painel é por atividade.
- O tutor se chama **monitor** (área: Monitoria), nunca Maria nem "parceiro de estudos", no aluno e no painel. Grupo do menu: "Acompanhamento", com **Painel** ("Ver seus dados de estudo", dashboard) e **Monitoria** ("Conversar com seu monitor"). Perguntas feitas no Painel ou no Início vão para a Monitoria (INTERFACE.md, Revisão 6). Textos, "Pergunte ao monitor…", "Enviar pergunta ao monitor". Rótulo das mensagens: "Monitor".
- Estados: vazio na home "Nenhuma trilha liberada para você."; no menu "Nenhuma trilha liberada" e "Não foi possível carregar suas trilhas" (sem ponto final); texto de erro na home sem negrito.

## Tema e cor

- Tema: **claro é o padrão ao abrir** (entrada e páginas); escuro pelo botão do menu. Fundo escuro é **preto (#000)**.
- No tema claro o fundo da área de conteúdo é branco. Bege (#fcfbf6, #f7f5ec, #fefdfa) só em destaques, campos e balões. O menu lateral usa #fdfcf9 no claro (v1.1); no escuro segue #0a1711.
- Ação principal: verde #00be85 com texto e ícone brancos (hover #00a974, pressionado #00925f). Vale para botões e setas de ação. Na Gestão também: botões verdes com texto e ícone brancos (1.1.1.b.36 substitui a exceção 1.1.39). Confirmações em linha: botão de confirmar verde claro com contorno verde vivo; remover em vermelho claro. Avatar do usuário: verde escuro #00593d com letra branca.
- Seta de abrir trilha na home: verde #00be85 (o mesmo da seta do menu), sem caixa de botão, do tamanho da fonte do título (19px), alinhada à direita da linha do título.
- Avatar do monitor nas mensagens: personagem do monitor (`crias-monitor.js`, ver abaixo); o círculo amarelo "M" saiu na v1.1. Sem Maria animada, sem emojis, sem reações. O símbolo do Crias (arquivo) aparece na entrada, no início e na trilha concluída.
- Rótulos "Acompanhamento" e "Trilhas" no menu: caixa alta, 11px, verde escuro #00593d (no escuro #5fe3b5), com linha fina ao lado.
- Títulos em Outfit, texto em Manrope. Cantos 12px (cartões 16px), botões em pílula.

## Personagem do monitor

- Definido em `Monitor Personagem.dc.html` (INTERFACE.md 1.1.28). Substitui o "M" amarelo nas mensagens do monitor; mensagens de conteúdo da trilha mantêm o símbolo do Crias.
- Sequência: carregando (anel orbita da direita para a esquerda), pulo único e suave (anel assenta abaixo dos olhos), parado com movimento leve só na última mensagem; mensagens anteriores ficam estáticas.

## Fundo

- Efeito de fundo único: **malha 3D**, na entrada e na home, lenta (um ciclo de 150s). Sem opções de fundo no menu do protótipo. Nas conversas fica só a névoa, a 70% da intensidade. No escuro a névoa verde é mais suave que no claro (aurora a 18%, brilho a 17%).
- Topo e base do Crias começam na cor sólida do fundo (branco no claro, preto no escuro) e transitam em degradê suave para os tons atuais. No menu lateral, o retângulo (#fdfcf9 no claro) tem cantos arredondados (59px na horizontal, 89px no topo e 114px na base na vertical) com borda levemente esfumada; as posições da transição não mudam.

## Esmaecimento e exemplos

- Texto que não cabe (linha, coluna, título, e-mail, arquivo) **esmaece no fim**, nunca reticências nem 2 linhas. Áreas com rolagem (tabelas na horizontal, listas na vertical) esmaecem na borda que ainda tem conteúdo. Ver INTERFACE.md 1.1.25.
- Exemplos da Gestão: toda instituição tem 3 trilhas e todos os campos preenchidos.
- Logo: "Crias | Educação" (antes Gestão), arquivo único `crias-logo-educacao.svg` (e `-branco`), 150×22 px, no design system.
- Posição inicial (Gestão): todo conteúdo começa 36px abaixo do subtítulo, na altura do botão Dados do Início da Instituição, em qualquer página (INTERFACE.md 1.1.30).
- Super admin, Início: "+ Nova instituição" na mesma linha do filtro, que ocupa a largura livre com 16px de respiro.

## Componentes

- Progresso: barra em degradê do amarelo #ffd500 para o verde #00be85, sem ícones ou órbitas, nos cards da home e no menu. O texto é só "Atividade X de Y".
- Em questão, o composer fica travado: "Selecione uma alternativa e continue...". Continuar só ativa com alternativa marcada.
- Menu lateral: Acompanhamento (Painel / Ver seus dados de estudo; Monitoria / Conversar com seu monitor), Trilhas. Rodapé: Claro/Escuro e linha de 38px com avatar "A", nome "Ana" (13px, 700, abre a página Perfil com o botão Suporte), seta à direita e, na ponta, o ícone de sair (21px) alinhado ao botão de recolher menu do topo. Avatar alinhado ao início do botão Claro.
- Home: cards com nome, seta amarela, barra, "Atividade X de Y" e "AGORA" com o nome da atividade; textos longos esmaecem no fim. Brilho de hover em amarelo a 3%. No celular os cards são levemente mais baixos para caber 3 trilhas sem rolar.
- Carregamento: símbolo completo desde o primeiro quadro (crias-symbol-192.png, brilho só depois da imagem), em toda tela de carregamento e na troca Aluno/Gestão (INTERFACE.md 1.1.38).
- Entrada: "Recuperar senha" e "Solicitar demonstração"; telefone com máscara ao fundo (1.1.1.b.38). Campos Login e Senha vazios, sem texto de exemplo, sem preenchimento automático. Cabeçalho e rodapé do site crias.org (INTERFACE.md 1.1.37): logo leva a https://www.crias.org na mesma aba, só o botão de tema (sem Agendar conversa), símbolo pulsando acima da caixa, rodapé com fundo branco, cabeçalho na cor do menu lateral (#fdfcf9 no claro, #0a1711 no escuro), malha só entre cabeçalho e rodapé.
- No celular a barra de mensagem não tem sombra externa (evita faixa de tom diferente na base).

## Web e celular

- Seguir as regras F1 a F29 de INTERFACE.md. Resumo: viewport de app sem zoom, campos com no mínimo 16px, anel de foco só na caixa (nunca retângulo dentro dela), nomes de trilha e títulos em uma linha com o fim esmaecendo (nunca reticências nem 2 linhas), menu em tela cheia no celular, altura pela var(--vv-height) (nunca 100vh), áreas seguras, página nunca rola.
- Referência de celular: iPhone 17 (402×874). O tweak "celular" do protótipo mostra o app nesse formato ao lado da versão web, no Aluno e na Gestão (v1.1). A Gestão segue os mesmos padrões de celular do Aluno (INTERFACE.md 1.1.27).

## Imagens

- Logo e símbolo sempre como arquivo (app: public/, protótipo: prototipo/assets/, design system: design-system/assets/). Nunca texto "Crias" no lugar do logo. Todo arquivo referenciado precisa estar no pacote.

## Protótipo

- Protótipo: no Aluno, o botão de atualizar saiu (1.1.1.b, Revisão 9). No canto superior direito fica o botão redondo de tela cheia (ícone "open in full"); em tela cheia vira X. Na Gestão fica no topo, antes do tema. Só aparece onde o navegador permite tela cheia (não no iPhone). Na Gestão (v1.1) o atualizar e o "S" saíram; o perfil muda pelos tweaks. A navegação é feita pelo próprio produto (menu lateral e seletor Aluno/Gestão).
- Gestão (v1.1): "Filtrar instituições" (Super admin) ou a etiqueta com o nome da escola (Instituição) ficam no topo da página, à direita, na linha do Voltar e com a mesma altura (36px, pílula); a largura acompanha o conteúdo. Saíram dos cabeçalhos das páginas.
- Tweaks do aluno: estado (normal, carregando, vazio, erro), trilhas na home (1 a 3), nome longo, efeitos 3D, celular, tablet (retrato ou paisagem) e primeiro acesso. A Gestão também tem o tweak tablet.
- Favicon oficial: crias-simbolo-luz.svg no Aluno e na Gestão; título da aba da Gestão "Crias | Educação".
- Nomes: os dois produtos são **Crias Aluno** e **Crias Educação** (antes Crias Gestão e, antes, "Crias Painel"; arquivo e pasta continuam `Crias Gestao` / `crias-gestao`). Aluno e Gestão são acessos diferentes, sem seletor no menu (1.1.1.b.38). "Painel" passa a ser só a página de dados do aluno dentro do Crias Aluno.
- Painel: individual, só dados do aluno logado, em dashboard com a barra do monitor embaixo; enviar leva à Monitoria. Ver INTERFACE.md, Revisão 6.

## Gestão (v1.1)

- Regras consolidadas e orientações para o backend em INTERFACE.md (1.1.35, 1.1.36 e "Orientações para o backend (Cursor), v1.1").
- Trilha: abas Configuração, Conteúdo, Alunos, Gabarito. Nova trilha: só Configuração (passos 1 a 6) e Prévia; geração sempre por prompt fixo do sistema + Configuração de geração.
- Importar planilha sempre adiciona. Exclusões pedem DELETAR; ações em massa por planilha (cadastrar, remover, ativar ou desativar, gabarito, senhas) usam a confirmação em linha com contagem.
- Botões 36px/13px; todo conteúdo começa em 203px (alinhado ao item selecionado do menu); esmaecimento com 18px de respiro.

## Gestão

- Perfis Super admin (todas as instituições) e Instituição (só a sua). Menu: Início, Dados, Trilhas; grupo **Configurações** com os subtítulos Usuários (Senhas, Permissões) e Sistema (Prompts, API e documentação). Senhas e Prompts só para Master. Gabarito é aba da trilha. Todo "Voltar" volta para a tela anterior (histórico). Ver INTERFACE.md 1.1.12 e 1.1.15.

## Regras 1.2 (Thiago, valem para toda a aplicação)

- **Login:** pode usar OU e-mail OU telefone (pelo menos um; nome sempre obrigatório). O sistema identifica o que foi digitado. Com os dois, a pessoa escolhe qual vale para a senha (`login_identifier`). Código e pendências de backend em `frontend/crias-gestao/src/lib/loginRule.ts` e `docs/ORIENTACOES-CURSOR-1.2.md` (**CURSOR**: ler antes de publicar).
- **Salvar:** o botão Salvar fica oculto e só aparece quando há alteração na página que precise de confirmação. Ações em massa confirmam na própria tela e não usam o Salvar do topo.
- **Perfis editáveis:** o Super admin edita o menu de Admin e Básico (coleção `admin_profiles`).
