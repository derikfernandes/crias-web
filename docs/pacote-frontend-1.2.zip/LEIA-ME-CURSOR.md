# Orientações para o Cursor: pacote 1.2 (antes 1.1.1.b)

Lido por quem vai subir o 1.2 e publicar. Itens marcados **CURSOR** são trabalho de backend ou deploy que o frontend NÃO faz.

## 1. Regra de login (Thiago, obrigatória)
- Pode usar **OU e-mail OU telefone** (pelo menos um). Nome sempre obrigatório. Vale para aluno e para usuário da Educação.
- O sistema identifica sozinho o que foi digitado (e-mail, telefone ou ID do aluno).
- Se a pessoa tem os dois, ela **escolhe qual vale para a senha**: campo `login_identifier` (`'phone'` ou `'email'`). Sem o campo, vale o que existir; com os dois, o telefone.
- Código de referência: `frontend/crias-gestao/src/lib/loginRule.ts` (comentário completo + `effectiveLoginIdentifier`, `looksLikeEmail`).
- **CURSOR:** (a) `identifyStudent` respeitar `login_identifier`; (b) login da Educação por telefone (hoje só Firebase e-mail/senha), por função de servidor + custom token; (c) definir/gerar senha da Educação pelo servidor (hoje só e-mail de redefinição).

## 2. Banco (campos e coleções novos)
| Onde | Campo | Observação |
| --- | --- | --- |
| `students` | `email` (string, minúsculas, opcional) | Telefone pode ficar vazio se houver e-mail |
| `students` | `login_identifier` (`phone` \| `email`, opcional) | Só faz sentido com os dois preenchidos |
| `admin_users` | `name`, `phone_number`, `login_identifier` (opcionais) | |
| `admin_users` | ID `tel_<dígitos>` | Usuário sem e-mail |
| `admin_profiles/{admin\|basico}` | `nav_permissions` (lista de chaves de menu), `updated_at` | **Nova coleção.** Perfis editáveis pelo Super admin. Ao salvar, o frontend também reescreve `nav_permissions` dos usuários daquele perfil |
- **CURSOR:** `firestore.rules` já tem `admin_profiles`; fazer o deploy das regras.
- `api/student.ts`: POST e PATCH aceitam `email` e `login_identifier`; telefone opcional se houver e-mail.

## 3. O que mudou no frontend (resumo)
- Tela cheia (Aluno e Educação), menu no topo da Educação, logo Crias | Educação, Perfil, Usuários unificado.
- Cancelar e Salvar só aparecem com alteração pendente; aviso ao sair sem salvar; ação em massa confirma na própria tela (com "Essa ação não pode ser desfeita.") e NÃO usa o Salvar do topo. "Cancelar" não desfaz ação em massa já aplicada.
- Ações em massa: `lib/bulkActions.ts` (leitura e validação), `lib/studentBulk.ts` (gravação), `components/BulkPanel.tsx`.
- Senha de aluno gerada na tela: pendente até o Salvar do topo e gravada por `updateStudentPassword`. **CURSOR:** conferir a auditoria ("nova senha fica registrada") que a rota `regenerate` fazia.
- Excluir usuário aparece sempre (não depende de "Editar").
- `npm test` completo tem 3 falhas que já existiam (`check-design-boundaries`, arquivos do `main` do sócio).

## 4. Antes de publicar
`npm run typecheck && npx vitest run && npm run build`, deploy das regras do Firestore, conferir o login do aluno por telefone e por e-mail.
