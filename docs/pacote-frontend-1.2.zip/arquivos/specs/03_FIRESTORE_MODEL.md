# Firestore Model — Crias Trilhas

## Regra geral

A gestão administrativa usa Firestore Client SDK para leitura e escrita.
O app web do aluno e demais consumidores externos usam API HTTP, que acessa Firestore via backend/admin SDK.

## Collections

### `institutions`

Documento:

```text
institutions/{institution_id}
```

Campos:

- `name`: string
- `type`: string
- `active`: boolean
- `public_link`: string opcional
- `created_at`: timestamp
- `updated_at`: timestamp

### `students`

Documento:

```text
students/{student_id}
```

Campos:

- `institution_id`: string
- `name`: string
- `phone_number`: string normalizada (pode ser vazio se houver `email`)
- `email`: string em minúsculas, opcional (1.1.1.b). Cadastro exige telefone OU e-mail. O login do aluno já aceita e-mail
- `login_identifier`: `'phone'` | `'email'`, opcional. Com telefone e e-mail, qual vale para a senha (regra em frontend/crias-gestao/src/lib/loginRule.ts)
- `school_level`: string
- `school_grade`: string
- `student_level`: 1 | 2 | 3
- `active`: boolean
- `created_at`: timestamp
- `updated_at`: timestamp

### `trails`

Documento:

```text
trails/{trail_id}
```

Campos:

- `institution_id`: string
- `name`: string
- `description`: string
- `subject`: string
- `default_total_steps_per_stage`: number
- `active`: boolean
- `phase_blueprint`: array opcional
- `created_at`: timestamp
- `updated_at`: timestamp

### `trail_stages`

Documento:

```text
trail_stages/{trail_id}_stage_{stage_number}
```

Campos:

- `trail_id`: string
- `stage_number`: number
- `title`: string
- `stage_type`: `ai` | `fixed` | `exercise`
- `prompt`: string | null
- `is_released`: boolean
- `active`: boolean
- `created_at`: timestamp
- `updated_at`: timestamp

### `trail_stage_questions`

Documento:

```text
trail_stage_questions/{trail_id}_stage_{stage_number}_question_{question_number}
```

Campos:

- `trail_id`: string
- `stage_number`: number
- `question_number`: number
- `title`: string
- `content`: string
- `correct_option`: string | null
- `options`: array | null
- `explanation`: string | null
- `is_released`: boolean
- `active`: boolean
- `created_at`: timestamp
- `updated_at`: timestamp

### `student_trails`

Documento:

```text
student_trails/{student_id}_trail_{trail_id}
```

Campos:

- `student_id`: string
- `institution_id`: string
- `trail_id`: string
- `current_stage_number`: number (>= 1)
- `current_question_number`: number (>= 1)
- `status`: `not_started` | `in_progress` | `completed` | `blocked`
- `started_at`: timestamp | null
- `completed_at`: timestamp | null
- `last_interaction_at`: timestamp | null
- `created_at`: timestamp
- `updated_at`: timestamp

Uso:

- progresso canônico do aluno na trilha;
- consumido pelo player web via `next-content` / `advance`;
- administrável na gestão (vínculo, posição, block/complete).

### `counters`

Documento:

```text
counters/trails
```

Campos:

- `next`: number

Uso:

- gerar ids sequenciais `t1`, `t2`, `t3`.

## Regras de modelagem

- Não criar novos campos sem atualizar esta spec.
- Não alterar nomes de collections sem plano de migração.
- Não alterar padrão de ids sem revisar o contrato do player web e da API.
- Campos consumidos pela API do aluno devem ser estáveis.
### Vínculo ativo ou inativo (v1.1)

- Aluno ativo na trilha = existe `student_trails` e `status` diferente de `blocked`.
- Inativar = `status: blocked` (mantém histórico e progresso). Reativar volta o status pelo progresso (`completed`, `in_progress` ou `not_started`).
- Remover aluno da instituição = `students.active = false` (mantém histórico; o aluno continua na base).

### Sem campos novos na v1.1

Objetivo, orientações, alternativas por exercício e perfis (Super admin, Admin, Básico) não são gravados em campos novos. Objetivo e orientações valem só na tela e no envio à IA; o perfil é uma combinação pronta de `is_super_admin`, `is_master` e `nav_permissions`.


### `admin_users` (campos opcionais novos, 1.1.1.b)

- `name`: string, opcional. Nome do usuário da Educação
- `phone_number`: string, opcional. Telefone do usuário
- `login_identifier`: `'phone'` | `'email'`, opcional (mesma regra do aluno)

O acesso ao painel continua pelo e-mail (ID do documento e login do Firebase Auth).

### `admin_profiles` (nova, 1.2)

```text
admin_profiles/{admin|basico}
```

- `nav_permissions`: lista de chaves de menu (`home`, `dash`, `trilhas`, `alunos`, `senhas`, `admin`)
- `updated_at`: timestamp

Sem o documento valem os padrões de `frontend/crias-gestao/src/lib/adminProfiles.ts`. Ao salvar, o frontend também reescreve `nav_permissions` dos usuários de `admin_users` daquele perfil.
