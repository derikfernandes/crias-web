import {
  useEffect,
  useLayoutEffect,
  useMemo,
  useRef,
  useState,
  useTransition,
} from 'react'
import type * as XLSX from 'xlsx'
import { collection, getDocs, query, where } from 'firebase/firestore'
import { useSearchParams } from 'react-router-dom'
import { DashboardPageView } from '../design/views/DashboardPageView'
import {
  DASHBOARD_STUDENT_COLUMNS,
  type DashboardPillRowView,
  type DashboardStudentChartFilter,
  type DashboardStudentColumnKey,
  type DashboardStudentSortKey,
  type DashboardTab,
} from '../design/types/dashboardPageView'
import { db } from '../lib/firebase'
import {
  EMPTY_AGENT_USAGE,
  formatAgentLastActivity,
  mergeAgentRowsByLabel,
  messagesPerTutorPerDay,
  type AgentUsagePeriodDays,
  type AgentUsageView,
} from '../lib/agentUsage'
import {
  INSTITUTIONS_COLLECTION,
  snapshotToInstitution,
} from '../lib/institutionFirestore'
import {
  snapshotToExerciseAttempt,
  EXERCISE_ATTEMPTS_COLLECTION,
} from '../lib/exerciseAttemptFirestore'
import {
  activityCountByTrail,
  activityKeysByTrail,
  isActivityKeyDoneOnLink,
  isStageDoneOnLink,
  type ActivityKey,
} from '../lib/gestaoMetrics'
import {
  accuracyAggregate,
  answersFromAnswerMap,
  answersFromAttempts,
  answersMatchGabarito,
  gabaritoFromQuestions,
  isNonGradableAnswer,
  mergeAnswerSources,
} from '../lib/acertoMedio'
import {
  getCachedInstitution,
  mergeCachedInstitutions,
  setCachedInstitution,
  type DashboardInstitutionSnapshot,
} from '../lib/dashboardInstitutionCache'
import { prefetchSiblingInstitutions } from '../lib/prefetchInstitutionDashboard'
import { getCachedAnswerMap, setCachedAnswerMap } from '../lib/answerMapCache'
import { dashboardAccuracyGate } from '../lib/dashboardAccuracyGate'
import {
  agentUsageFromMetrics,
  fetchInstitutionMetrics,
  getCachedMetrics,
  mergeMetricsViews,
  type InstitutionDashboardMetricsView,
} from '../lib/dashboardMetricsApi'
import {
  formatAtualizadoAs,
  METRICS_FRESH_MS,
  nextPinnedComputedAt,
  oldestComputedAt,
} from '../lib/metricsUpdatedAt'
import {
  getSummarySession,
  mergeSessionAgentUsage,
  mergeSessionAnswerMaps,
  setSummarySession,
} from '../lib/dashboardSummarySessionCache'
import {
  accuracyFromAttempts,
  engagementFromLinks,
  progressFromLinks,
} from '../lib/dashboardTrailProgress'
import { snapshotToStudent, STUDENTS_COLLECTION } from '../lib/studentFirestore'
import {
  snapshotToStudentTrail,
  STUDENT_TRAILS_COLLECTION,
} from '../lib/studentTrailFirestore'
import { snapshotToTrail, TRAILS_COLLECTION } from '../lib/trailFirestore'
import {
  snapshotToTrailStage,
  TRAIL_STAGES_COLLECTION,
} from '../lib/trailStageFirestore'
import {
  snapshotToTrailStageQuestion,
  TRAIL_STAGE_QUESTIONS_COLLECTION,
} from '../lib/trailStageQuestionFirestore'
import { fetchDashboardLogSummary } from '../lib/dashboardSummaryApi'
import {
  buildForcedCompletionLookup,
  collectForcedCompletions,
  FORCED_COMPLETION_EXPORT_LESSON_LABEL,
  FORCED_COMPLETION_EXPORT_TOPIC_LABEL,
  upsertForcedCompletionMarker,
  type ForcedCompletionTarget,
} from '../lib/forcedLessonCompletion'
import { loadXlsx } from '../lib/loadXlsx'
import { studentPath, trailPath } from '../lib/paths'
import { usePermissions } from '../hooks/usePermissions'
import { useGestao } from '../hooks/useGestao'
import {
  formatInstParam,
  parseInstParam,
  shouldRestoreTopFilterWhenEmpty,
  shouldSyncTopFilterFromUrlIds,
} from '../lib/dadosInstitutionSync'
import { downloadText, toCsv } from '../lib/tableFiles'
import { correctToLetter, letterOf } from '../lib/trailActivities'
import { resolveExerciseOptions } from '../lib/trilha/exerciseOptions'
import type { Institution } from '../types/institution'
import type { Student } from '../types/student'
import type { StudentTrail } from '../types/studentTrail'
import type { Trail } from '../types/trail'
import type { TrailStage } from '../types/trailStage'
import type { TrailStageQuestion } from '../types/trailStageQuestion'

const LAST_INSTITUTION_ID_STORAGE_KEY = 'trilha_admin_selected_institution_id'
const STUDENTS_PAGE_SIZE = 20
const PILLS_PAGE_SIZE = 20
const ALL_STUDENT_COLUMNS = DASHBOARD_STUDENT_COLUMNS

type StudentColumnKey = DashboardStudentColumnKey
type StudentSortKey = DashboardStudentSortKey

type StudentRow = {
  student: Student
  released: number
  done: number
  completionPct: number | null
  lessonsReleased: number
  lessonsDone: number
  lessonsCompletionPct: number | null
  correct: number
  wrong: number
  accuracyPct: number | null
  engagementStatus: StudentEngagementStatus
}

type StudentEngagementStatus = 'notStarted' | 'inProgress' | 'completed'

function getStudentEngagementStatus(
  row: StudentRow,
): StudentEngagementStatus {
  if (row.completionPct !== null && row.completionPct >= 100) return 'completed'
  if (row.engagementStatus === 'completed') return 'completed'
  if (
    row.engagementStatus === 'inProgress' ||
    (row.completionPct !== null && row.completionPct > 0)
  ) {
    return 'inProgress'
  }
  return 'notStarted'
}

function getCompletionBucketKey(completion: number | null): string | null {
  if (completion === null) return null
  if (completion <= 20) return '0-20'
  if (completion <= 40) return '21-40'
  if (completion <= 60) return '41-60'
  if (completion <= 80) return '61-80'
  return '81-100'
}

type PillRow = {
  key: string
  trailId: string
  trailName: string
  subject: string
  stageNumber: number
  questionNumber: number
  title: string
  content: string
  gabarito: string
  total: number
  correct: number
  wrong: number
  accuracyPct: number
  /** Enunciado sem alternativas, com o texto de cada alternativa e quantas respostas teve. */
  exerciseLabel: string
  statement: string
  alternatives: Array<{ key: string; text: string; count: number; correct: boolean }>
}

type PillSortKey =
  | 'trail'
  | 'position'
  | 'total'
  | 'correct'
  | 'wrong'
  | 'accuracyPct'

function compareNullableNumber(a: number | null, b: number | null): number {
  if (a === null && b === null) return 0
  if (a === null) return 1
  if (b === null) return -1
  return a - b
}

function pct(num: number, den: number): number | null {
  if (den <= 0) return null
  return Math.round((num / den) * 100)
}

function formatPctExport(v: number | null): string {
  return v === null ? '' : `${v}%`
}

function slugFileName(value: string): string {
  return (
    value
      .normalize('NFD')
      .replace(/[\u0300-\u036f]/g, '')
      .toLowerCase()
      .replace(/[^a-z0-9]+/g, '-')
      .replace(/^-|-$/g, '') || 'trilha'
  )
}

/** Cabeçalho de coluna na planilha: aula (A) × tópico da aula (T). */
function lessonTopicColumn(topicNumber: number, lessonNumber: number): string {
  return `A${lessonNumber}.T${topicNumber}`
}

/** Rótulo de coluna do histórico: "Atividade N · Etapa K - nome" (1.1.1.b, F). */
function activityStageLabel(
  trailId: string,
  topicNumber: number,
  lessonNumber: number,
  stageByKey: Map<string, TrailStage>,
): string {
  const title = stageByKey.get(`${trailId}|${topicNumber}`)?.title?.trim()
  return `Atividade ${lessonNumber} · Etapa ${topicNumber}${title ? ` - ${title}` : ''}`
}

const FIRESTORE_IN_LIMIT = 30

function chunkArray<T>(items: T[], size: number): T[][] {
  const chunks: T[][] = []
  for (let i = 0; i < items.length; i += size) {
    chunks.push(items.slice(i, i + size))
  }
  return chunks
}

function normalizeAnswer(value: string): string {
  let s = value.trim()
  if (
    (s.startsWith('"') && s.endsWith('"')) ||
    (s.startsWith("'") && s.endsWith("'"))
  ) {
    s = s.slice(1, -1).trim()
  }
  return s
}

function answersMatch(studentAnswer: string, correctOption: string): boolean {
  return answersMatchGabarito(studentAnswer, correctOption)
}

/** Exibe gabarito numérico como letra: 1→A, 2→B, 3→C. */
function formatGabaritoLetter(value: string): string {
  const normalized = normalizeAnswer(value).toLowerCase()
  if (!normalized) return 'N/A'
  const fromNumber: Record<string, string> = {
    '1': 'A',
    '2': 'B',
    '3': 'C',
  }
  if (fromNumber[normalized]) return fromNumber[normalized]
  const upper = normalized.toUpperCase()
  if (upper === 'A' || upper === 'B' || upper === 'C') return upper
  return upper
}

type LogAggregates = {
  doneByStudent: Map<string, Set<string>>
  answerMap: Map<string, string>
}

function scoreStudentFromAnswerMap(
  studentId: string,
  enrolledTrailIds: Set<string>,
  answerMap: Map<string, string>,
  stageByKey: Map<string, TrailStage>,
  questionByKey: Map<string, TrailStageQuestion>,
  deselectedStages: Set<string>,
  deselectedQuestions: Set<number>,
): { correct: number; wrong: number } {
  let correct = 0
  let wrong = 0
  const prefix = `${studentId}|`

  for (const [key, answer] of answerMap) {
    if (!key.startsWith(prefix) || !answer.trim()) continue
    // Continuar / "0" / comandos de UI: fora do acerto.
    if (isNonGradableAnswer(answer)) continue

    const rest = key.slice(prefix.length)
    const sep1 = rest.indexOf('|')
    const sep2 = rest.indexOf('|', sep1 + 1)
    if (sep1 < 0 || sep2 < 0) continue

    const trailId = rest.slice(0, sep1)
    const stage = Number(rest.slice(sep1 + 1, sep2))
    const question = Number(rest.slice(sep2 + 1))
    if (!Number.isFinite(stage) || !Number.isFinite(question)) continue
    // Clamp: ignora chaves fora de faixa (ex.: question 101 / stage 13).
    if (stage < 1 || question < 1) continue
    if (!enrolledTrailIds.has(trailId)) continue
    if (deselectedStages.has(`${trailId}|${stage}`)) continue
    if (deselectedQuestions.has(question)) continue

    const stageRec = stageByKey.get(`${trailId}|${stage}`)
    if (stageRec?.stage_type !== 'exercise') continue

    const questionRec = questionByKey.get(`${trailId}|${stage}|${question}`)
    // Sem registro no catálogo = fora de faixa → ignora.
    if (!questionRec) continue
    // Atividade anulada: fora do denominador (nem acerto nem erro).
    if (questionRec.annulled === true) continue
    const gabarito = (questionRec.correct_option ?? '').trim()
    if (!gabarito) continue

    if (answersMatch(answer, gabarito)) correct += 1
    else wrong += 1
  }

  return { correct, wrong }
}

const DATA_SOURCES = 3
/** Stages e atividades (carregados por trilha) também entram no gate de loading. */
const META_SOURCES = 2
/** Passos de progresso: fontes de dados + metadados + 1 passo de métricas (logs). */
const TOTAL_LOAD_STEPS = DATA_SOURCES + META_SOURCES + 1

const EMPTY_LOG_AGGREGATES: LogAggregates = {
  doneByStudent: new Map(),
  answerMap: new Map(),
}

type XlsxModule = typeof import('xlsx')

function forceWorksheetCellString(
  xlsx: XlsxModule,
  worksheet: XLSX.WorkSheet,
  row: number,
  col: number,
  value: string,
) {
  const ref = xlsx.utils.encode_cell({ r: row, c: col })
  worksheet[ref] = { t: 's', v: value }
}

const CORRESPONDENCE_HEADERS = ['Código', 'Etapa da atividade', 'Enunciado'] as const

function buildTrailCorrespondenceRows(
  trailId: string,
  positions: { stage: number; question: number }[],
  stageByKey: Map<string, TrailStage>,
  questionByKey: Map<string, TrailStageQuestion>,
): string[][] {
  return positions.map((p) => {
    const question = questionByKey.get(`${trailId}|${p.stage}|${p.question}`)
    return [
      lessonTopicColumn(p.stage, p.question),
      stageByKey.get(`${trailId}|${p.stage}`)?.title?.trim() ?? '',
      (question?.content ?? question?.title ?? '').trim(),
    ]
  })
}

function appendCorrespondenceSheet(
  xlsx: XlsxModule,
  workbook: XLSX.WorkBook,
  trailId: string,
  positions: { stage: number; question: number }[],
  stageByKey: Map<string, TrailStage>,
  questionByKey: Map<string, TrailStageQuestion>,
) {
  const legendRows = buildTrailCorrespondenceRows(
    trailId,
    positions,
    stageByKey,
    questionByKey,
  )
  const legendSheet = xlsx.utils.aoa_to_sheet([
    [...CORRESPONDENCE_HEADERS],
    ...legendRows,
  ])
  CORRESPONDENCE_HEADERS.forEach((header, colIndex) => {
    forceWorksheetCellString(xlsx, legendSheet, 0, colIndex, header)
  })
  legendRows.forEach((row, rowIndex) => {
    row.forEach((value, colIndex) => {
      if (value.length > 0) {
        forceWorksheetCellString(xlsx, legendSheet, rowIndex + 1, colIndex, value)
      }
    })
  })
  xlsx.utils.book_append_sheet(workbook, legendSheet, 'Correspondência')
}

type TopicPosition = { stage: number; question: number }

function filterTrailTopicPositions(
  trailId: string,
  positions: TopicPosition[],
  deselectedStages: Set<string>,
  deselectedQuestions: Set<number>,
): TopicPosition[] {
  return positions.filter(
    (p) =>
      !deselectedStages.has(`${trailId}|${p.stage}`) &&
      !deselectedQuestions.has(p.question),
  )
}

function groupTopicsByLesson(positions: TopicPosition[]): Map<number, TopicPosition[]> {
  const byQuestion = new Map<number, TopicPosition[]>()
  for (const p of positions) {
    const arr = byQuestion.get(p.question)
    if (arr) arr.push(p)
    else byQuestion.set(p.question, [p])
  }
  return byQuestion
}

function isLessonCompleteForTrail(
  trailId: string,
  topics: TopicPosition[],
  studentDone: Set<string>,
): boolean {
  // Com a regra de conclusão forçada, o último tópico não-exercício já entra
  // em `studentDone` via `collectForcedCompletions` antes desta checagem.
  return topics.every((p) =>
    studentDone.has(`${trailId}|${p.stage}|${p.question}`),
  )
}

function computeLessonMetricsForTrails(
  trailIds: Iterable<string>,
  questionsByTrail: Map<string, TopicPosition[]>,
  studentDone: Set<string>,
  deselectedStages: Set<string>,
  deselectedQuestions: Set<number>,
): { lessonsReleased: number; lessonsDone: number; lessonsCompletionPct: number | null } {
  const releasedKeys = new Set<string>()
  const doneKeys = new Set<string>()

  for (const trailId of trailIds) {
    const selected = filterTrailTopicPositions(
      trailId,
      questionsByTrail.get(trailId) ?? [],
      deselectedStages,
      deselectedQuestions,
    )
    for (const [questionNumber, topics] of groupTopicsByLesson(selected)) {
      if (topics.length === 0) continue
      const lessonKey = `${trailId}|${questionNumber}`
      releasedKeys.add(lessonKey)
      if (isLessonCompleteForTrail(trailId, topics, studentDone)) {
        doneKeys.add(lessonKey)
      }
    }
  }

  const lessonsReleased = releasedKeys.size
  const lessonsDone = doneKeys.size
  return {
    lessonsReleased,
    lessonsDone,
    lessonsCompletionPct: pct(lessonsDone, lessonsReleased),
  }
}

function trailLessonNumbers(
  trailId: string,
  questionsByTrail: Map<string, TopicPosition[]>,
  deselectedStages: Set<string>,
  deselectedQuestions: Set<number>,
): number[] {
  const selected = filterTrailTopicPositions(
    trailId,
    questionsByTrail.get(trailId) ?? [],
    deselectedStages,
    deselectedQuestions,
  )
  return [...groupTopicsByLesson(selected).keys()].sort((a, b) => a - b)
}

function appendLessonsProgressSheet(
  xlsx: XlsxModule,
  workbook: XLSX.WorkBook,
  trail: Trail,
  students: Student[],
  questionsByTrail: Map<string, TopicPosition[]>,
  doneByStudent: Map<string, Set<string>>,
  deselectedStages: Set<string>,
  deselectedQuestions: Set<number>,
  forcedLookup: Set<string>,
) {
  const lessonNumbers = trailLessonNumbers(
    trail.id,
    questionsByTrail,
    deselectedStages,
    deselectedQuestions,
  )
  const lessonHeaders = lessonNumbers.map((n) => `Atividade ${n}`)
  const headers = [
    'Nome',
    'Telefone',
    ...lessonHeaders,
    'Atividades liberadas',
    'Atividades feitas',
    '% conclusão (atividades)',
  ]

  const sortedStudents = [...students].sort((a, b) =>
    (a.name || '').localeCompare(b.name || '', 'pt-BR', {
      sensitivity: 'base',
    }),
  )

  const rows = sortedStudents.map((student) => {
    const studentDone = doneByStudent.get(student.id) ?? new Set()
    const metrics = computeLessonMetricsForTrails(
      [trail.id],
      questionsByTrail,
      studentDone,
      deselectedStages,
      deselectedQuestions,
    )
    const byQuestion = groupTopicsByLesson(
      filterTrailTopicPositions(
        trail.id,
        questionsByTrail.get(trail.id) ?? [],
        deselectedStages,
        deselectedQuestions,
      ),
    )
    const lessonCells = lessonNumbers.map((n) => {
      const topics = byQuestion.get(n) ?? []
      if (topics.length === 0) return ''
      if (!isLessonCompleteForTrail(trail.id, topics, studentDone)) return 'Não'
      const wasForced = topics.some((p) =>
        forcedLookup.has(
          `${student.id}|${trail.id}|${p.stage}|${p.question}`,
        ),
      )
      return wasForced ? FORCED_COMPLETION_EXPORT_LESSON_LABEL : 'Sim'
    })
    return [
      student.name || student.id,
      student.phone_number || '',
      ...lessonCells,
      metrics.lessonsReleased,
      metrics.lessonsDone,
      formatPctExport(metrics.lessonsCompletionPct),
    ]
  })

  const sheet = xlsx.utils.aoa_to_sheet([headers, ...rows])
  headers.forEach((header, colIndex) => {
    forceWorksheetCellString(xlsx, sheet, 0, colIndex, header)
  })
  rows.forEach((row, rowIndex) => {
    row.forEach((value, colIndex) => {
      if (typeof value === 'string' && value.length > 0) {
        forceWorksheetCellString(xlsx, sheet, rowIndex + 1, colIndex, value)
      }
    })
  })
  xlsx.utils.book_append_sheet(workbook, sheet, 'Aulas')
}

export function DashboardPage() {
  const { filterInstitutions } = usePermissions()
  const gestao = useGestao()
  const [searchParams, setSearchParams] = useSearchParams()
  const instFromUrl = searchParams.get('inst')?.trim() || null
  const [trailFilter, setTrailFilter] = useState<Set<string> | null>(null)
  const [activeTab, setActiveTab] = useState<DashboardTab>('students')
  // Oportunidades (menor e maior acerto) aparecem sempre; os dados dos exercícios entram desde o início.
  const [questionsDataEnabled, setQuestionsDataEnabled] = useState(true)
  const [isQuestionsPending, startQuestionsTransition] = useTransition()
  // Seed do GestaoContext: volta Início↔Dados sem BootSymbol por getDocs.
  const [institutions, setInstitutions] = useState<Institution[]>(() =>
    gestao.institutions.length > 0 ? gestao.institutions : [],
  )
  const [loadingInst, setLoadingInst] = useState(
    () => gestao.institutions.length === 0,
  )
  const [instError, setInstError] = useState<string | null>(null)
  const [selectedId, setSelectedId] = useState<string | null>(() => {
    const fromUrl = new URLSearchParams(window.location.search).get('inst')?.trim()
    if (fromUrl) return fromUrl
    try {
      const stored = window.localStorage.getItem(LAST_INSTITUTION_ID_STORAGE_KEY)
      if (stored?.trim()) return stored.trim()
    } catch {
      // ignore
    }
    return gestao.scopedInstitutions[0]?.id ?? null
  })

  const [students, setStudents] = useState<Student[]>([])
  const [trails, setTrails] = useState<Trail[]>([])
  const [studentTrails, setStudentTrails] = useState<StudentTrail[]>([])
  const [attempts, setAttempts] = useState<
    import('../types/exerciseAttempt').ExerciseAttempt[]
  >([])
  const [logAggregates, setLogAggregates] = useState<LogAggregates>(
    EMPTY_LOG_AGGREGATES,
  )
  const [stages, setStages] = useState<TrailStage[]>([])
  const [questions, setQuestions] = useState<TrailStageQuestion[]>([])
  const [loadingData, setLoadingData] = useState(false)
  const [loadingMeta, setLoadingMeta] = useState(false)
  /** Já houve pelo menos um load completo: troca de filtro não usa BootSymbol. */
  const [hasDashboardContent, setHasDashboardContent] = useState(() => {
    const ids = [...gestao.selectedIds].filter(Boolean)
    if (ids.length === 0) return false
    return ids.every((id) => Boolean(getCachedInstitution(id)))
  })
  /** Atualizando em segundo plano (cache hit ou keep-previous). */
  const [isRefreshing, setIsRefreshing] = useState(false)
  /** selectedIdsKey cujos students/attempts estão na tela (evita % instável). */
  const [dataScopeKey, setDataScopeKey] = useState(() => {
    const ids = [...gestao.selectedIds].filter(Boolean).sort()
    if (ids.length === 0) return ''
    if (ids.every((id) => Boolean(getCachedInstitution(id)))) {
      return ids.join('|')
    }
    return ''
  })
  const [loadingLogs, setLoadingLogs] = useState(false)
  /** Instituições com summary pronto no escopo atual. */
  const [logsReadyIds, setLogsReadyIds] = useState<Set<string>>(() => new Set())
  /** Fetch terminou com falha sem cache para alguma selecionada. */
  const [logsFailed, setLogsFailed] = useState(false)
  /** Persiste o período do monitor entre troca de instituição e Início↔Dados. */
  const [agentPeriodDays, setAgentPeriodDays] =
    useState<AgentUsagePeriodDays>(() => {
      try {
        const raw = sessionStorage.getItem('gestao.monitorPeriodDays')
        if (raw === '0' || raw === '7' || raw === '30') {
          return Number(raw) as AgentUsagePeriodDays
        }
      } catch {
        // ignore
      }
      return 0
    })
  const setAgentPeriodDaysPersist = (days: AgentUsagePeriodDays) => {
    setAgentPeriodDays(days)
    try {
      sessionStorage.setItem('gestao.monitorPeriodDays', String(days))
    } catch {
      // ignore
    }
  }
  /** Métricas pré-agregadas (Início+Dados) — evita rebuild de 57k answers. */
  const [metricsByInst, setMetricsByInst] = useState<
    Map<string, InstitutionDashboardMetricsView>
  >(() => {
    // Seed síncrono: volta Dados/Sol sem BootSymbol nem refetch bloqueante.
    const seed = new Map<string, InstitutionDashboardMetricsView>()
    for (const id of gestao.selectedIds) {
      const hit = getCachedMetrics(id)
      if (hit) seed.set(id, hit)
    }
    return seed
  })
  const [metricsForceRefreshing, setMetricsForceRefreshing] = useState(false)
  const [stampPin, setStampPin] = useState<{ key: string; ms: number } | null>(
    null,
  )
  const [metricsScopeKey, setMetricsScopeKey] = useState(() => {
    const ids = [...gestao.selectedIds].filter(Boolean).sort()
    if (ids.length === 0) return ''
    if (ids.every((id) => getCachedMetrics(id))) return ids.join('|')
    return ''
  })
  /** Escopo do monitor (agentUsage) publicado — evita stale de outra instituição. */
  const [agentScopeKey, setAgentScopeKey] = useState(() => {
    const ids = [...gestao.selectedIds].filter(Boolean).sort()
    if (ids.length === 0) return ''
    let period: AgentUsagePeriodDays = 0
    try {
      const raw = sessionStorage.getItem('gestao.monitorPeriodDays')
      if (raw === '0' || raw === '7' || raw === '30') {
        period = Number(raw) as AgentUsagePeriodDays
      }
    } catch {
      // ignore
    }
    if (!ids.every((id) => agentUsageFromMetrics(getCachedMetrics(id), period))) {
      return ''
    }
    return `${ids.join('|')}|${period}`
  })
  const metricsGenerationRef = useRef(0)
  const [loadStepsDone, setLoadStepsDone] = useState(0)
  const loadGenerationRef = useRef(0)
  const logsGenerationRef = useRef(0)
  const [loadStepsTotal, setLoadStepsTotal] = useState(TOTAL_LOAD_STEPS)
  const [loadPercent, setLoadPercent] = useState(0)
  const [loadLabel, setLoadLabel] = useState('')
  const [dataError, setDataError] = useState<string | null>(null)
  const [logsError, setLogsError] = useState<string | null>(null)
  const [logsRetryKey, setLogsRetryKey] = useState(0)
  const [agentUsage, setAgentUsage] = useState<AgentUsageView>(() => {
    const ids = [...gestao.selectedIds].filter(Boolean).sort()
    let period: AgentUsagePeriodDays = 0
    try {
      const raw = sessionStorage.getItem('gestao.monitorPeriodDays')
      if (raw === '0' || raw === '7' || raw === '30') {
        period = Number(raw) as AgentUsagePeriodDays
      }
    } catch {
      // ignore
    }
    const usages = ids.map((id) =>
      agentUsageFromMetrics(getCachedMetrics(id), period),
    )
    if (ids.length === 0 || usages.some((u) => !u)) {
      return { ...EMPTY_AGENT_USAGE, periodDays: period }
    }
    let total = 0
    let uniqueStudents = 0
    const agents = []
    const series: AgentUsageView['series'] = []
    for (const u of usages) {
      total += u!.totalMessages
      uniqueStudents +=
        typeof u!.uniqueStudents === 'number' && u!.uniqueStudents > 0
          ? u!.uniqueStudents
          : new Set(u!.agents.flatMap((a) => a.studentIds)).size ||
            u!.agents.reduce((n, a) => n + (a.uniqueStudents || 0), 0)
      agents.push(...u!.agents)
      series.push(...u!.series)
    }
    return {
      periodDays: period,
      totalMessages: total,
      uniqueStudents,
      agents: mergeAgentRowsByLabel(agents).map((row) => ({
        ...row,
        pctOfTotal:
          total > 0 ? Math.round((row.messages / total) * 1000) / 10 : 0,
      })),
      series,
    }
  })
  const [selectedAgentTrailId, setSelectedAgentTrailId] = useState<
    string | null
  >(null)
  const [agentUsageLoading, setAgentUsageLoading] = useState(false)
  const [agentUsagePresent, setAgentUsagePresent] = useState(true)
  const initialLogsLoadedRef = useRef(false)
  const agentSummaryInstRef = useRef<string | null>(null)
  const dashboardLoadStartedAtRef = useRef(0)
  const loadProgressRef = useRef({ done: 0, total: TOTAL_LOAD_STEPS })
  const loadTargetPercentRef = useRef(0)

  const computeLoadPercent = (done: number, total: number, complete = false) => {
    if (complete) return 100
    if (total <= 0) return 0
    return Math.min(99, Math.round((done / total) * 100))
  }

  const syncLoadProgress = (label: string, options?: { complete?: boolean }) => {
    const { done, total } = loadProgressRef.current
    const pct = computeLoadPercent(done, total, options?.complete)
    loadTargetPercentRef.current = pct
    setLoadStepsDone(done)
    setLoadStepsTotal(total)
    setLoadLabel(label)
    if (options?.complete) {
      setLoadPercent(100)
    }
  }

  // Filtros da tabela de alunos
  const [nameFilter, setNameFilter] = useState('')
  const [studentPick, setStudentPick] = useState<Set<string> | null>(null)
  const [pctMin, setPctMin] = useState(0)
  const [pctMax, setPctMax] = useState(100)
  const [studentChartFilter, setStudentChartFilter] =
    useState<DashboardStudentChartFilter | null>(null)
  const [hiddenColumns, setHiddenColumns] = useState<Set<StudentColumnKey>>(
    new Set(),
  )
  const [showColumnPicker, setShowColumnPicker] = useState(false)
  /** Stages desmarcados (excluídos do cálculo). Vazio = todos incluídos. */
  const [deselectedStages, setDeselectedStages] = useState<Set<string>>(
    new Set(),
  )
  /** Atividades desmarcadas (número da atividade na etapa). Vazio = todas incluídas. */
  const [deselectedQuestions, setDeselectedQuestions] = useState<Set<number>>(
    new Set(),
  )
  const [showStagePicker, setShowStagePicker] = useState(false)
  const [showQuestionPicker, setShowQuestionPicker] = useState(false)
  const [exportingTrailId, setExportingTrailId] = useState<string | null>(null)
  const [exportingPillTrailId, setExportingPillTrailId] = useState<string | null>(
    null,
  )
  const [exportError, setExportError] = useState<string | null>(null)
  const [studentSort, setStudentSort] = useState<{
    key: StudentSortKey
    dir: 'asc' | 'desc'
  }>({ key: 'name', dir: 'asc' })
  const [studentPage, setStudentPage] = useState(1)

  // Filtros do ranking de pílulas / aba Atividades
  const [pillSearch, setPillSearch] = useState('')
  const [pillTrailFilter, setPillTrailFilter] = useState('')
  const [pillMinResponses, setPillMinResponses] = useState(1)
  const [pillAccMin, setPillAccMin] = useState(0)
  const [pillAccMax, setPillAccMax] = useState(100)
  const [pillPage, setPillPage] = useState(1)
  const [pillSort, setPillSort] = useState<{
    key: PillSortKey
    dir: 'asc' | 'desc'
  }>({ key: 'accuracyPct', dir: 'asc' })
  useEffect(() => {
    let cancelled = false

    async function run() {
      // Já tem lista do contexto: não bloqueia UI; refresca em background.
      if (gestao.institutions.length > 0) {
        setInstitutions(gestao.institutions)
        setLoadingInst(false)
      }
      if (!db) {
        setLoadingInst(false)
        return
      }
      try {
        const snap = await getDocs(collection(db, INSTITUTIONS_COLLECTION))
        if (cancelled) return
        setInstitutions(snap.docs.map(snapshotToInstitution))
        setInstError(null)
        setLoadingInst(false)
      } catch (err) {
        if (cancelled) return
        // Mantém seed do contexto se o refresh falhar.
        if (gestao.institutions.length === 0) {
          setInstError(
            err instanceof Error
              ? err.message
              : 'Erro ao carregar instituições.',
          )
        }
        setLoadingInst(false)
      }
    }

    void run()
    return () => {
      cancelled = true
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [])

  useEffect(() => {
    if (!selectedId?.trim()) return
    window.localStorage.setItem(LAST_INSTITUTION_ID_STORAGE_KEY, selectedId)
  }, [selectedId])

  // Chave estável: Set novo a cada render quebrava deps e gerava loop de setState.
  const selectedIdsKey = useMemo(
    () => [...gestao.selectedIds].sort().join('|'),
    [gestao.selectedIds],
  )
  const activeInstitutionIds = useMemo(
    () => [...gestao.selectedIds].filter(Boolean).sort(),
    [gestao.selectedIds],
  )

  // URL ?inst=i1 ou ?inst=i1,i2 → topo (multi). Não colapsar multi para 1.
  useEffect(() => {
    const allowed = new Set(gestao.institutions.map((i) => i.id))
    const urlIds = parseInstParam(instFromUrl).filter((id) => allowed.has(id))
    if (urlIds.length > 0) {
      if (shouldSyncTopFilterFromUrlIds(urlIds, gestao.selectedIds)) {
        gestao.setSelectedIds(new Set(urlIds))
      }
      if (urlIds.length === 1 && selectedId !== urlIds[0]) {
        setSelectedId(urlIds[0]!)
      }
      return
    }
    // Sem URL válida: garante pelo menos 1 no topo.
    if (shouldRestoreTopFilterWhenEmpty(gestao.selectedIds.size)) {
      let fallback = selectedId
      if (!fallback || !allowed.has(fallback)) {
        try {
          const stored = window.localStorage.getItem(
            LAST_INSTITUTION_ID_STORAGE_KEY,
          )
          if (stored && allowed.has(stored)) fallback = stored
        } catch {
          // ignore
        }
      }
      if (!fallback) fallback = gestao.institutions[0]?.id ?? null
      if (fallback) {
        gestao.setSelectedIds(new Set([fallback]))
        setSelectedId(fallback)
      }
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps -- instFromUrl + institutions
  }, [instFromUrl, gestao.institutions])

  // Topo → URL (um ou vários). Fonte de verdade do multi-select.
  useEffect(() => {
    if (gestao.selectedIds.size === 0) return
    const formatted = formatInstParam(gestao.selectedIds)
    const cur = searchParams.get('inst') || ''
    if (cur === formatted) return
    const next = new URLSearchParams(searchParams)
    next.set('inst', formatted)
    setSearchParams(next, { replace: true })
  }, [selectedIdsKey, searchParams, setSearchParams, gestao.selectedIds])

  // Select da página: quando o topo tem exatamente 1, alinha o valor do <select>.
  useEffect(() => {
    if (gestao.selectedIds.size !== 1) return
    const only = [...gestao.selectedIds][0]
    if (only && only !== selectedId) setSelectedId(only)
  }, [selectedIdsKey, gestao.selectedIds, selectedId])

  function selectInstitution(id: string) {
    setSelectedId(id)
    gestao.setSelectedIds(new Set([id]))
    // URL otimista (mesmo tick) — evita flash do ?inst= anterior.
    const formatted = formatInstParam([id])
    if (searchParams.get('inst') !== formatted) {
      const next = new URLSearchParams(searchParams)
      next.set('inst', formatted)
      setSearchParams(next, { replace: true })
    }
    // Síncrono: nunca mostra monitor/métricas da instituição anterior.
    const hit = getCachedMetrics(id)
    if (hit) {
      const map = new Map([[id, hit]])
      setMetricsByInst(map)
      setMetricsScopeKey(id)
      const usage = agentUsageFromMetrics(hit, agentPeriodDays)
      if (usage) {
        setAgentUsage(usage)
        setAgentScopeKey(`${id}|${agentPeriodDays}`)
        setAgentUsageLoading(false)
        setAgentUsagePresent(true)
      } else {
        setAgentUsage({ ...EMPTY_AGENT_USAGE, periodDays: agentPeriodDays })
        setAgentScopeKey('')
        setAgentUsageLoading(true)
      }
    } else {
      setMetricsByInst(new Map())
      setMetricsScopeKey('')
      setAgentUsage({ ...EMPTY_AGENT_USAGE, periodDays: agentPeriodDays })
      setAgentScopeKey('')
      setAgentUsageLoading(true)
    }
  }

  // Troca do conjunto ativo: limpa filtro de trilhas.
  const prevActiveIdsRef = useRef<string>('')
  useEffect(() => {
    if (prevActiveIdsRef.current && prevActiveIdsRef.current !== selectedIdsKey) {
      setTrailFilter(null)
    }
    prevActiveIdsRef.current = selectedIdsKey
  }, [selectedIdsKey])

  // Antes do paint: monitor/métricas só da instituição nova (topo/URL também).
  useLayoutEffect(() => {
    const ids = activeInstitutionIds
    const scopeKey = selectedIdsKey
    if (ids.length === 0) return
    const seed = new Map<string, InstitutionDashboardMetricsView>()
    for (const id of ids) {
      const hit = getCachedMetrics(id)
      if (hit) seed.set(id, hit)
    }
    if (seed.size === ids.length) {
      setMetricsByInst(seed)
      setMetricsScopeKey(scopeKey)
      applyAgentFromMetrics(scopeKey, ids, seed, agentPeriodDays)
      return
    }
    // Sem cache completo: tira escopo antigo e mantém só seeds parciais da nova
    // (evita flash da instituição anterior sem esperar rede).
    if (metricsScopeKey !== scopeKey) {
      setMetricsByInst(seed)
      setMetricsScopeKey('')
      setAgentUsage({ ...EMPTY_AGENT_USAGE, periodDays: agentPeriodDays })
      setAgentScopeKey('')
      setAgentUsageLoading(true)
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps -- applyAgent defined below; intentional sync gate
  }, [selectedIdsKey, activeInstitutionIds, agentPeriodDays])

  // Após 1º conteúdo: prefetch das outras instituições (Sol primeiro).
  useEffect(() => {
    if (!hasDashboardContent) return
    const allIds = institutions.map((i) => i.id).filter(Boolean)
    if (allIds.length <= 1) return
    const t = window.setTimeout(() => {
      prefetchSiblingInstitutions(activeInstitutionIds, allIds)
    }, 400)
    return () => window.clearTimeout(t)
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [hasDashboardContent, selectedIdsKey, institutions])

  useEffect(() => {
    let cancelled = false
    const generation = ++loadGenerationRef.current
    const instIds = activeInstitutionIds
    const scopeKey = selectedIdsKey
    const loadStarted = performance.now()

    function applyCoreSnapshot(
      snap: DashboardInstitutionSnapshot,
      key: string,
    ) {
      setStudents(snap.students)
      setTrails(snap.trails)
      setStudentTrails(snap.studentTrails)
      setAttempts(snap.attempts)
      if (snap.stages.length > 0 || snap.questions.length > 0) {
        setStages(snap.stages)
        setQuestions(snap.questions)
      }
      if (snap.answerMap.size > 0 || snap.doneByStudent.size > 0) {
        setLogAggregates({
          doneByStudent: snap.doneByStudent,
          answerMap: snap.answerMap,
        })
        // Não publica agentUsage aqui (pode ser de outro período/escopo).
        // O effect de logs hidrata monitor com sessão + periodDays.
        initialLogsLoadedRef.current = true
      }
      setDataScopeKey(key)
      setHasDashboardContent(true)
    }

    function cacheSplit(input: {
      students: Student[]
      trails: Trail[]
      studentTrails: StudentTrail[]
      attempts: import('../types/exerciseAttempt').ExerciseAttempt[]
      stages: TrailStage[]
      questions: TrailStageQuestion[]
    }) {
      for (const id of instIds) {
        const prev = getCachedInstitution(id)
        const instStudents = input.students.filter(
          (s) => s.institution_id === id,
        )
        const instStudentIds = new Set(instStudents.map((s) => s.id))
        const instTrails = input.trails.filter((t) => t.institution_id === id)
        const instTrailIds = new Set(instTrails.map((t) => t.id))
        setCachedInstitution(id, {
          students: instStudents,
          trails: instTrails,
          studentTrails: input.studentTrails.filter(
            (l) => l.institution_id === id,
          ),
          attempts: input.attempts.filter((a) =>
            instStudentIds.has(a.student_id),
          ),
          stages:
            input.stages.length > 0
              ? input.stages.filter((s) => instTrailIds.has(s.trail_id))
              : (prev?.stages ?? []),
          questions:
            input.questions.length > 0
              ? input.questions.filter((q) => instTrailIds.has(q.trail_id))
              : (prev?.questions ?? []),
          doneByStudent: prev?.doneByStudent ?? new Map(),
          answerMap: prev?.answerMap ?? new Map(),
          agentUsage: prev?.agentUsage ?? EMPTY_AGENT_USAGE,
          agentUsagePresent: prev?.agentUsagePresent ?? true,
          loadedAt: Date.now(),
        })
      }
    }

    async function run() {
      if (!db || instIds.length === 0) {
        setStudents([])
        setTrails([])
        setStudentTrails([])
        setAttempts([])
        setLogAggregates(EMPTY_LOG_AGGREGATES)
        setAgentUsage(EMPTY_AGENT_USAGE)
        setAgentUsagePresent(true)
        setDataError(null)
        setLogsError(null)
        setLoadingData(false)
        setLoadingMeta(false)
        setIsRefreshing(false)
        setHasDashboardContent(false)
        setDataScopeKey('')
        setLoadingLogs(false)
        initialLogsLoadedRef.current = false
        setAgentUsageLoading(false)
        setSelectedAgentTrailId(null)
        setLoadStepsDone(0)
        setLoadStepsTotal(TOTAL_LOAD_STEPS)
        loadProgressRef.current = { done: 0, total: TOTAL_LOAD_STEPS }
        loadTargetPercentRef.current = 0
        setLoadPercent(0)
        setLoadLabel('')
        return
      }

      const cached = mergeCachedInstitutions(instIds)
      const warmComplete = Boolean(
        cached &&
          cached.stages.length > 0 &&
          cached.questions.length > 0,
      )
      loadProgressRef.current = { done: 0, total: TOTAL_LOAD_STEPS }
      loadTargetPercentRef.current = 0
      dashboardLoadStartedAtRef.current = performance.now()
      setSelectedAgentTrailId(null)
      setLoadStepsDone(0)
      setLoadStepsTotal(TOTAL_LOAD_STEPS)
      setLoadPercent(0)
      setLoadLabel(
        warmComplete
          ? 'Atualizando…'
          : cached
            ? 'Carregando…'
            : 'Carregando alunos e trilhas…',
      )

      if (cached) {
        // Hit: UI na hora. Cache completo = sem refetch (evita fila 2s→9s).
        applyCoreSnapshot(cached, scopeKey)
        setLoadingData(false)
        setLoadingMeta(!warmComplete)
        setIsRefreshing(false)
        if (warmComplete) {
          loadProgressRef.current.done = TOTAL_LOAD_STEPS
          syncLoadProgress('Pronto', { complete: true })
          console.info(
            `[dashboard] cache hit ${Math.round(performance.now() - loadStarted)}ms scope=${scopeKey}`,
          )
          return
        }
      } else {
        // Miss: mantém conteúdo anterior (outro escopo) ou BootSymbol no 1º load.
        setIsRefreshing(hasDashboardContent)
        setLoadingData(true)
        setLoadingMeta(true)
      }

      const dbOk = db
      const loadedSources = new Set<string>()

      const done = (source: string) => {
        if (loadedSources.has(source)) return
        loadedSources.add(source)
        loadProgressRef.current.done += 1
        syncLoadProgress('Carregando alunos e trilhas…')
        if (loadedSources.size >= DATA_SOURCES) {
          setLoadingData(false)
        }
      }

      try {
        // Busca só o que falta no cache.
        const missingIds = instIds.filter((id) => !getCachedInstitution(id))
        const fetchIds = missingIds.length > 0 ? missingIds : instIds

        const fetchChunks = chunkArray(fetchIds, FIRESTORE_IN_LIMIT)
        async function docsForFetch(collectionName: string) {
          const snaps = await Promise.all(
            fetchChunks.map((chunk) =>
              getDocs(
                query(
                  collection(dbOk, collectionName),
                  where(
                    'institution_id',
                    chunk.length === 1 ? '==' : 'in',
                    chunk.length === 1 ? chunk[0]! : chunk,
                  ),
                ),
              ),
            ),
          )
          return snaps.flatMap((s) => s.docs)
        }

        const usePartial =
          missingIds.length > 0 && missingIds.length < instIds.length
        const [studentDocs, trailDocs, linkDocs] = await Promise.all([
          docsForFetch(STUDENTS_COLLECTION),
          docsForFetch(TRAILS_COLLECTION),
          docsForFetch(STUDENT_TRAILS_COLLECTION),
        ])
        if (cancelled || generation !== loadGenerationRef.current) return
        let nextStudents = studentDocs.map(snapshotToStudent)
        let nextTrails = trailDocs.map(snapshotToTrail)
        let nextStudentTrails = linkDocs.map(snapshotToStudentTrail)

        if (usePartial) {
          for (const id of instIds) {
            if (missingIds.includes(id)) continue
            const prev = getCachedInstitution(id)
            if (!prev) continue
            nextStudents = nextStudents.concat(prev.students)
            nextTrails = nextTrails.concat(prev.trails)
            nextStudentTrails = nextStudentTrails.concat(prev.studentTrails)
          }
        }

        const studentIds = nextStudents.map((s) => s.id).filter(Boolean)
        let nextAttempts: import('../types/exerciseAttempt').ExerciseAttempt[] =
          []
        if (studentIds.length > 0) {
          const needAttemptFetch = usePartial
            ? nextStudents
                .filter((s) => missingIds.includes(s.institution_id))
                .map((s) => s.id)
            : studentIds
          const chunks = chunkArray(
            needAttemptFetch.length > 0 ? needAttemptFetch : studentIds,
            FIRESTORE_IN_LIMIT,
          )
          const attemptSnaps = await Promise.all(
            chunks.map((chunk) =>
              getDocs(
                query(
                  collection(dbOk, EXERCISE_ATTEMPTS_COLLECTION),
                  where('student_id', 'in', chunk),
                ),
              ),
            ),
          )
          nextAttempts = attemptSnaps.flatMap((snap) =>
            snap.docs.map(snapshotToExerciseAttempt),
          )
          if (usePartial) {
            for (const id of instIds) {
              if (missingIds.includes(id)) continue
              const prev = getCachedInstitution(id)
              if (prev) nextAttempts = nextAttempts.concat(prev.attempts)
            }
          }
        }
        if (cancelled || generation !== loadGenerationRef.current) return

        cacheSplit({
          students: nextStudents,
          trails: nextTrails,
          studentTrails: nextStudentTrails,
          attempts: nextAttempts,
          stages: [],
          questions: [],
        })

        const merged = mergeCachedInstitutions(instIds)
        if (merged) {
          applyCoreSnapshot(merged, scopeKey)
        } else {
          setStudents(nextStudents)
          setTrails(nextTrails)
          setStudentTrails(nextStudentTrails)
          setAttempts(nextAttempts)
          setDataScopeKey(scopeKey)
          setHasDashboardContent(true)
        }
        setDataError(null)
        setIsRefreshing(false)
        done('students')
        done('trails')
        done('studentTrails')
        console.info(
          `[dashboard] core fetch ${Math.round(performance.now() - loadStarted)}ms scope=${scopeKey}`,
        )
      } catch (err) {
        if (cancelled || generation !== loadGenerationRef.current) return
        const message =
          err instanceof Error ? err.message : 'Erro ao carregar dados.'
        setDataError(message)
        if (!hasDashboardContent) {
          setStudents([])
          setTrails([])
          setStudentTrails([])
          setAttempts([])
        }
        setIsRefreshing(false)
        done('students')
        done('trails')
        done('studentTrails')
      }
    }

    void run()
    return () => {
      cancelled = true
    }
    // hasDashboardContent intencional fora das deps (só gate de UI).
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [selectedIdsKey, activeInstitutionIds])

  const trailIdsKey = useMemo(
    () =>
      trails
        .map((t) => t.id)
        .filter(Boolean)
        .sort()
        .join('\0'),
    [trails],
  )

  // Stages e atividades filtrados pelas trilhas da instituição (em chunks de 30
  // IDs por limitação do operador "in"), em vez de baixar as coleções inteiras.
  // One-shot (getDocs): conteúdo muda pouco durante a sessão do dashboard.
  useEffect(() => {
    let cancelled = false

    async function run() {
      if (!db || activeInstitutionIds.length === 0) {
        setStages([])
        setQuestions([])
        setLoadingMeta(false)
        return
      }
      if (loadingData) return

      const dbOk = db
      const trailIds = trailIdsKey ? trailIdsKey.split('\0') : []

      loadProgressRef.current.done = Math.min(
        loadProgressRef.current.done,
        DATA_SOURCES,
      )

      const metaDone = (source: 'stages' | 'questions') => {
        loadProgressRef.current.done += 1
        syncLoadProgress('Carregando conteúdo das trilhas…')
        if (source === 'questions') {
          setLoadingMeta(false)
          setIsRefreshing(false)
        }
      }

      if (trailIds.length === 0) {
        setStages([])
        setQuestions([])
        metaDone('stages')
        metaDone('questions')
        return
      }

      // Meta já aplicada do cache do escopo: não refetch (evita fila 2s→9s).
      const metaFromCache =
        dataScopeKey === selectedIdsKey &&
        stages.length > 0 &&
        questions.length > 0
      if (metaFromCache) {
        setLoadingMeta(false)
        setIsRefreshing(false)
        return
      }
      setLoadingMeta(true)
      const chunks = chunkArray(trailIds, FIRESTORE_IN_LIMIT)

      try {
        const stageSnaps = await Promise.all(
          chunks.map((chunk) =>
            getDocs(
              query(
                collection(dbOk, TRAIL_STAGES_COLLECTION),
                where('trail_id', 'in', chunk),
              ),
            ),
          ),
        )
        if (cancelled) return
        const nextStages = stageSnaps.flatMap((snap) =>
          snap.docs.map(snapshotToTrailStage),
        )
        setStages(nextStages)
        metaDone('stages')

        const questionSnaps = await Promise.all(
          chunks.map((chunk) =>
            getDocs(
              query(
                collection(dbOk, TRAIL_STAGE_QUESTIONS_COLLECTION),
                where('trail_id', 'in', chunk),
              ),
            ),
          ),
        )
        if (cancelled) return
        const nextQuestions = questionSnaps.flatMap((snap) =>
          snap.docs.map(snapshotToTrailStageQuestion),
        )
        setQuestions(nextQuestions)
        // Atualiza cache por instituição com stages/questions.
        for (const id of activeInstitutionIds) {
          const prev = getCachedInstitution(id)
          if (!prev) continue
          const trailIdSet = new Set(prev.trails.map((t) => t.id))
          setCachedInstitution(id, {
            ...prev,
            stages: nextStages.filter((s) => trailIdSet.has(s.trail_id)),
            questions: nextQuestions.filter((q) => trailIdSet.has(q.trail_id)),
            loadedAt: Date.now(),
          })
        }
        metaDone('questions')
      } catch (err) {
        if (cancelled) return
        setDataError(err instanceof Error ? err.message : 'Erro ao carregar conteúdo.')
        if (!hasDashboardContent) {
          setStages([])
          setQuestions([])
        }
        metaDone('stages')
        metaDone('questions')
      }
    }

    void run()
    return () => {
      cancelled = true
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [selectedIdsKey, trailIdsKey, loadingData])

  function applyAgentFromMetrics(
    scopeKey: string,
    instIds: string[],
    map: Map<string, InstitutionDashboardMetricsView>,
    period: AgentUsagePeriodDays,
  ): boolean {
    const usages = instIds.map((id) =>
      agentUsageFromMetrics(map.get(id), period),
    )
    if (usages.some((u) => !u)) {
      setAgentUsage({ ...EMPTY_AGENT_USAGE, periodDays: period })
      setAgentScopeKey('')
      setAgentUsageLoading(true)
      return false
    }
    let total = 0
    let uniqueStudents = 0
    const agents = []
    const series: AgentUsageView['series'] = []
    for (const u of usages) {
      total += u!.totalMessages
      uniqueStudents +=
        typeof u!.uniqueStudents === 'number' && u!.uniqueStudents > 0
          ? u!.uniqueStudents
          : new Set(u!.agents.flatMap((a) => a.studentIds)).size ||
            u!.agents.reduce((n, a) => n + (a.uniqueStudents || 0), 0)
      agents.push(...u!.agents)
      series.push(...u!.series)
    }
    const mergedAgents = mergeAgentRowsByLabel(agents).map((row) => ({
      ...row,
      pctOfTotal:
        total > 0 ? Math.round((row.messages / total) * 1000) / 10 : 0,
    }))
    setAgentUsage({
      periodDays: period,
      totalMessages: total,
      uniqueStudents,
      agents: mergedAgents,
      series,
    })
    setAgentUsagePresent(true)
    setAgentScopeKey(`${scopeKey}|${period}`)
    setAgentUsageLoading(false)
    if (instIds.length > 1) {
      console.info(
        `[dashboard] monitor metrics scope=${scopeKey} total=${total} parts=${instIds
          .map(
            (id) =>
              `${id}:${agentUsageFromMetrics(map.get(id), period)?.totalMessages ?? '?'}`,
          )
          .join('+')}`,
      )
    }
    return true
  }

  // Troca só de período do monitor: reaplica agent_usage_by_period local (0ms).
  const prevPeriodRef = useRef(agentPeriodDays)
  useEffect(() => {
    if (prevPeriodRef.current === agentPeriodDays) return
    prevPeriodRef.current = agentPeriodDays
    if (
      metricsScopeKey === selectedIdsKey &&
      activeInstitutionIds.every((id) => metricsByInst.has(id))
    ) {
      applyAgentFromMetrics(
        selectedIdsKey,
        activeInstitutionIds,
        metricsByInst,
        agentPeriodDays,
      )
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [agentPeriodDays])

  // Refetch a cada 10 min com a tela aberta (SWR: não limpa valor).
  useEffect(() => {
    const ids = activeInstitutionIds
    if (ids.length === 0) return
    let cancelled = false
    const tick = async () => {
      if (document.visibilityState === 'hidden') return
      const next = new Map<string, InstitutionDashboardMetricsView>()
      for (const id of ids) {
        const prev = getCachedMetrics(id)
        if (prev) next.set(id, prev)
      }
      let changed = false
      for (const id of ids) {
        try {
          const m = await fetchInstitutionMetrics(id, { revalidate: true })
          if (cancelled) return
          next.set(id, m)
          changed = true
        } catch {
          // mantém
        }
      }
      if (cancelled || !changed) return
      setMetricsByInst(new Map(next))
      if (ids.every((id) => next.has(id))) {
        setMetricsScopeKey(selectedIdsKey)
        applyAgentFromMetrics(selectedIdsKey, ids, next, agentPeriodDays)
      }
    }
    const timer = window.setInterval(() => {
      void tick()
    }, METRICS_FRESH_MS)
    const onVis = () => {
      if (document.visibilityState === 'visible') void tick()
    }
    document.addEventListener('visibilitychange', onVis)
    return () => {
      cancelled = true
      window.clearInterval(timer)
      document.removeEventListener('visibilitychange', onVis)
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [selectedIdsKey, activeInstitutionIds, agentPeriodDays])

  const forceRefreshMetrics = () => {
    const ids = activeInstitutionIds
    if (ids.length === 0 || metricsForceRefreshing) return
    const scopeKey = ids.join(',')
    void (async () => {
      setMetricsForceRefreshing(true)
      const next = new Map<string, InstitutionDashboardMetricsView>()
      for (const id of ids) {
        const prev = getCachedMetrics(id)
        if (prev) next.set(id, prev)
      }
      try {
        for (const id of ids) {
          try {
            const m = await fetchInstitutionMetrics(id, {
              force: true,
              timeoutMs: 55_000,
            })
            next.set(id, m)
            // Atualiza UI instituição a instituição (Sol ~40s).
            setMetricsByInst(new Map(next))
          } catch {
            // mantém
          }
        }
        setMetricsByInst(new Map(next))
        if (ids.every((id) => next.has(id))) {
          setMetricsScopeKey(selectedIdsKey)
          applyAgentFromMetrics(selectedIdsKey, ids, next, agentPeriodDays)
        }
        const freshOldest = oldestComputedAt(
          ids.map((id) => next.get(id)?.computedAt),
        )
        if (freshOldest != null && scopeKey) {
          setStampPin({ key: scopeKey, ms: freshOldest })
        }
      } finally {
        setMetricsForceRefreshing(false)
      }
    })()
  }

  const stampScopeKey = activeInstitutionIds.join(',')
  const stampAllReady =
    activeInstitutionIds.length > 0 &&
    activeInstitutionIds.every((id) => {
      const at = metricsByInst.get(id)?.computedAt
      return typeof at === 'number' && at > 0
    })
  const liveOldest = stampAllReady
    ? oldestComputedAt(
        activeInstitutionIds.map((id) => metricsByInst.get(id)?.computedAt),
      )
    : null
  useEffect(() => {
    if (metricsForceRefreshing) return
    const next = nextPinnedComputedAt({
      scopeKey: stampScopeKey,
      liveOldest,
      pinned: stampPin,
    })
    if (
      next &&
      (stampPin?.key !== next.key || stampPin?.ms !== next.ms)
    ) {
      setStampPin(next)
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps -- pin só no settle/escopo
  }, [stampScopeKey, liveOldest, metricsForceRefreshing])
  const metricsUpdatedAtLabel = formatAtualizadoAs(
    stampPin?.key === stampScopeKey ? stampPin.ms : liveOldest,
  )

  // Métricas pré-agregadas (KB): desbloqueia Acerto/Exercícios/Monitor/Conclusão
  // sem baixar answerMap da Sol. Mesma chave de sessão do Início.
  useEffect(() => {
    let cancelled = false
    const generation = ++metricsGenerationRef.current
    const instIds = activeInstitutionIds
    const scopeKey = selectedIdsKey
    const started = performance.now()

    if (instIds.length === 0) {
      setMetricsByInst(new Map())
      setMetricsScopeKey('')
      return () => {
        cancelled = true
      }
    }

    // Hidrata cache síncrono (volta Sol <0,5s).
    const seed = new Map<string, InstitutionDashboardMetricsView>()
    for (const id of instIds) {
      const hit = getCachedMetrics(id)
      if (hit) seed.set(id, hit)
    }
    if (seed.size === instIds.length) {
      setMetricsByInst(seed)
      setMetricsScopeKey(scopeKey)
      setLogsReadyIds(new Set(instIds))
      setLoadingLogs(false)
      applyAgentFromMetrics(scopeKey, instIds, seed, agentPeriodDays)
      console.info(
        `[dashboard] metrics cache-hit ${Math.round(performance.now() - started)}ms scope=${scopeKey}`,
      )
      // SWR: rede mesmo com sessão (senão nunca atualiza Crias 22→10).
      void (async () => {
        const next = new Map(seed)
        for (const id of instIds) {
          if (cancelled || generation !== metricsGenerationRef.current) return
          try {
            const m = await fetchInstitutionMetrics(id, { revalidate: true })
            next.set(id, m)
          } catch {
            // mantém seed
          }
        }
        if (cancelled || generation !== metricsGenerationRef.current) return
        setMetricsByInst(new Map(next))
        applyAgentFromMetrics(scopeKey, instIds, next, agentPeriodDays)
      })()
      return () => {
        cancelled = true
      }
    }

    // Sem cache completo: Carregando… (não N/A / não número velho).
    setMetricsScopeKey('')
    setAgentUsage({ ...EMPTY_AGENT_USAGE, periodDays: agentPeriodDays })
    setAgentScopeKey('')
    setAgentUsageLoading(true)
    setLoadingLogs(true)
    setLogsReadyIds(new Set(seed.keys()))

    void (async () => {
      const missing = instIds.filter((id) => !seed.has(id))
      missing.sort((a, b) => {
        if (a === 'i2') return -1
        if (b === 'i2') return 1
        return a.localeCompare(b)
      })
      const next = new Map(seed)
      const errors: string[] = []
      for (const id of missing) {
        if (cancelled || generation !== metricsGenerationRef.current) return
        try {
          const m = await fetchInstitutionMetrics(id)
          next.set(id, m)
          if (!cancelled && generation === metricsGenerationRef.current) {
            setMetricsByInst(new Map(next))
            setLogsReadyIds(new Set(next.keys()))
          }
        } catch (err) {
          errors.push(err instanceof Error ? err.message : String(err))
        }
      }
      if (cancelled || generation !== metricsGenerationRef.current) return

      const allReady = instIds.every((id) => next.has(id))
      setMetricsByInst(new Map(next))
      setMetricsScopeKey(allReady ? scopeKey : '')
      setLogsReadyIds(new Set(next.keys()))
      setLoadingLogs(!allReady)
      setLogsFailed(!allReady && errors.length > 0 && next.size === 0)
      setLogsError(
        !allReady && errors.length > 0
          ? errors[0] ?? 'Erro ao carregar métricas.'
          : null,
      )

      if (allReady) {
        applyAgentFromMetrics(scopeKey, instIds, next, agentPeriodDays)
        initialLogsLoadedRef.current = true
      } else {
        // Não publica agentScopeKey sem dados — evita KPI da instituição anterior.
        setAgentUsage({ ...EMPTY_AGENT_USAGE, periodDays: agentPeriodDays })
        setAgentScopeKey('')
        setAgentUsageLoading(true)
      }
      console.info(
        `[dashboard] metrics ${Math.round(performance.now() - started)}ms scope=${scopeKey} ready=${[...next.keys()].join(',')}`,
      )
    })()

    return () => {
      cancelled = true
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps -- agent period handled above
  }, [selectedIdsKey, activeInstitutionIds, logsRetryKey])

  // Uso do monitor + answerMap: /api/dashboard_summary (legado / fallback).
  // Com métricas prontas, NÃO baixa answerMap da Sol (evita 3–6s de merge).
  useEffect(() => {
    let cancelled = false
    const generation = ++logsGenerationRef.current
    const instIds = activeInstitutionIds

    if (instIds.length === 0) {
      agentSummaryInstRef.current = null
      initialLogsLoadedRef.current = false
      setAgentUsage(EMPTY_AGENT_USAGE)
      setAgentUsagePresent(true)
      setAgentUsageLoading(false)
      setLoadingLogs(false)
      setLogsReadyIds(new Set())
      setLogsFailed(false)
      setAgentScopeKey('')
      return () => {
        cancelled = true
      }
    }

    const scopeKey = selectedIdsKey
    const institutionChanged = agentSummaryInstRef.current !== scopeKey
    if (institutionChanged) {
      agentSummaryInstRef.current = scopeKey
      initialLogsLoadedRef.current = false
    }

    // Atalho: métricas cobrem KPIs + monitor + exercícios — sem answerMap.
    const metricsComplete =
      metricsScopeKey === scopeKey &&
      instIds.every((id) => getCachedMetrics(id) || metricsByInst.has(id))
    if (metricsComplete) {
      return () => {
        cancelled = true
      }
    }

    // Hidrata answerMap da sessão / answerMapCache / institution cache (Início→Dados).
    const fromSession = mergeSessionAnswerMaps(instIds)
    for (const id of instIds) {
      if (fromSession.readyIds.includes(id)) continue
      const am = getCachedAnswerMap(id)
      const inst = getCachedInstitution(id)
      if (am !== undefined) {
        fromSession.readyIds.push(id)
        fromSession.missingIds = fromSession.missingIds.filter((x) => x !== id)
        for (const [k, v] of am) fromSession.answerMap.set(k, v)
        if (inst) {
          for (const [sid, keys] of inst.doneByStudent) {
            const set = fromSession.doneByStudent.get(sid) ?? new Set<string>()
            for (const k of keys) set.add(k)
            fromSession.doneByStudent.set(sid, set)
          }
        }
      } else if (inst && (inst.answerMap.size > 0 || inst.doneByStudent.size > 0)) {
        fromSession.readyIds.push(id)
        fromSession.missingIds = fromSession.missingIds.filter((x) => x !== id)
        for (const [k, v] of inst.answerMap) fromSession.answerMap.set(k, v)
        for (const [sid, keys] of inst.doneByStudent) {
          const set = fromSession.doneByStudent.get(sid) ?? new Set<string>()
          for (const k of keys) set.add(k)
          fromSession.doneByStudent.set(sid, set)
        }
      }
    }

    const allAnswersReady = fromSession.missingIds.length === 0
    if (fromSession.readyIds.length > 0) {
      setLogAggregates({
        doneByStudent: fromSession.doneByStudent,
        answerMap: fromSession.answerMap,
      })
      setLogsReadyIds(new Set(fromSession.readyIds))
      if (allAnswersReady) initialLogsLoadedRef.current = true
    } else if (institutionChanged) {
      // Sem cache do novo escopo: limpa stale (nunca mostrar Teste em Sol).
      setLogAggregates(EMPTY_LOG_AGGREGATES)
      setLogsReadyIds(new Set())
    }

    const agentMerged = mergeSessionAgentUsage(instIds, agentPeriodDays)
    if (agentMerged.complete) {
      const mergedAgents = mergeAgentRowsByLabel(agentMerged.usage.agents).map(
        (row) => ({
          ...row,
          pctOfTotal:
            agentMerged.usage.totalMessages > 0
              ? Math.round(
                  (row.messages / agentMerged.usage.totalMessages) * 1000,
                ) / 10
              : 0,
        }),
      )
      setAgentUsage({
        periodDays: agentPeriodDays,
        totalMessages: agentMerged.usage.totalMessages,
        uniqueStudents: agentMerged.usage.uniqueStudents ?? 0,
        agents: mergedAgents,
        series: [],
      })
      setAgentUsagePresent(agentMerged.present)
      setAgentScopeKey(`${scopeKey}|${agentPeriodDays}`)
      setAgentUsageLoading(false)
      if (instIds.length > 1) {
        console.info(
          `[dashboard] monitor merge scope=${scopeKey} total=${agentMerged.usage.totalMessages} parts=${instIds
            .map((id) => {
              const u = mergeSessionAgentUsage([id], agentPeriodDays)
              return `${id}:${u.complete ? u.usage.totalMessages : '?'}`
            })
            .join('+')}`,
        )
      }
    } else {
      // Troca de instituição/período sem cache: Carregando… (não números velhos).
      // agentScopeKey fica '' até o fetch — prop deriva loading pelo mismatch.
      setAgentUsage({ ...EMPTY_AGENT_USAGE, periodDays: agentPeriodDays })
      setAgentScopeKey('')
      setAgentUsageLoading(true)
    }

    setLogsFailed(false)
    setLogsError(null)
    // Só o que falta na sessão. NÃO refetch só por troca de instituição
    // (Início→Dados / Sol↔Teste devem reutilizar a mesma chave de sessão).
    const needFetch =
      fromSession.missingIds.length > 0 || !agentMerged.complete
    setLoadingLogs(fromSession.missingIds.length > 0)
    const logsStarted = performance.now()

    async function run() {
      if (!needFetch && allAnswersReady && agentMerged.complete) {
        // Revalidação silenciosa só da Sol (maior) para manter cache Firestore quente.
        const warmId = instIds.includes('i2') ? 'i2' : instIds[0]!
        try {
          const summary = await fetchDashboardLogSummary(warmId, agentPeriodDays)
          if (cancelled || generation !== logsGenerationRef.current) return
          const prev = getCachedInstitution(warmId)
          if (prev) {
            setCachedInstitution(warmId, {
              ...prev,
              doneByStudent: summary.doneByStudent,
              answerMap: summary.answerMap,
              agentUsage: summary.agentUsage,
              agentUsagePresent: summary.agentUsagePresent,
              loadedAt: Date.now(),
            })
          }
          const refreshed = mergeSessionAnswerMaps(instIds)
          const agentRef = mergeSessionAgentUsage(instIds, agentPeriodDays)
          if (refreshed.missingIds.length === 0) {
            setLogAggregates({
              doneByStudent: refreshed.doneByStudent,
              answerMap: refreshed.answerMap,
            })
            setLogsReadyIds(new Set(refreshed.readyIds))
          }
          if (agentRef.complete) {
            const mergedAgents = mergeAgentRowsByLabel(agentRef.usage.agents).map(
              (row) => ({
                ...row,
                pctOfTotal:
                  agentRef.usage.totalMessages > 0
                    ? Math.round(
                        (row.messages / agentRef.usage.totalMessages) * 1000,
                      ) / 10
                    : 0,
              }),
            )
            setAgentUsage({
              periodDays: agentPeriodDays,
              totalMessages: agentRef.usage.totalMessages,
              uniqueStudents: agentRef.usage.uniqueStudents ?? 0,
              agents: mergedAgents,
              series: [],
            })
            setAgentScopeKey(`${scopeKey}|${agentPeriodDays}`)
          }
        } catch {
          // Best-effort warm; UI já tem dados.
        }
        setLoadingLogs(false)
        setAgentUsageLoading(false)
        return
      }

      try {
        const fetchIds =
          fromSession.missingIds.length > 0 ? fromSession.missingIds : instIds
        const settled = await Promise.allSettled(
          fetchIds.map((id) => fetchDashboardLogSummary(id, agentPeriodDays)),
        )
        if (cancelled || generation !== logsGenerationRef.current) return

        const ready = new Set(fromSession.readyIds)
        const errors: string[] = []

        for (let i = 0; i < fetchIds.length; i++) {
          const id = fetchIds[i]!
          const result = settled[i]!
          if (result.status === 'rejected') {
            const sess = getSummarySession(id)
            if (sess) {
              ready.add(id)
              continue
            }
            errors.push(
              result.reason instanceof Error
                ? result.reason.message
                : String(result.reason),
            )
            continue
          }
          const summary = result.value
          ready.add(id)
          setCachedAnswerMap(id, summary.answerMap)
          setSummarySession(
            id,
            summary,
            agentPeriodDays,
            summary.agentUsageByPeriod,
          )
          const prev = getCachedInstitution(id)
          if (prev) {
            setCachedInstitution(id, {
              ...prev,
              doneByStudent: summary.doneByStudent,
              answerMap: summary.answerMap,
              agentUsage: summary.agentUsage,
              agentUsagePresent: summary.agentUsagePresent,
              loadedAt: Date.now(),
            })
          }
        }

        if (generation !== logsGenerationRef.current) return

        const merged = mergeSessionAnswerMaps(instIds)
        const allReady = instIds.every((id) => ready.has(id) || merged.readyIds.includes(id))
        const failedHard =
          !allReady && errors.length > 0 && merged.readyIds.length === 0

        if (merged.readyIds.length > 0) {
          setLogAggregates({
            doneByStudent: merged.doneByStudent,
            answerMap: merged.answerMap,
          })
        }
        setLogsReadyIds(new Set([...ready, ...merged.readyIds]))

        const agentRef = mergeSessionAgentUsage(instIds, agentPeriodDays)
        if (agentRef.complete) {
          const mergedAgents = mergeAgentRowsByLabel(agentRef.usage.agents).map(
            (row) => ({
              ...row,
              pctOfTotal:
                agentRef.usage.totalMessages > 0
                  ? Math.round(
                      (row.messages / agentRef.usage.totalMessages) * 1000,
                    ) / 10
                  : 0,
            }),
          )
          setAgentUsage({
            periodDays: agentPeriodDays,
            totalMessages: agentRef.usage.totalMessages,
            uniqueStudents: agentRef.usage.uniqueStudents ?? 0,
            agents: mergedAgents,
            series: [],
          })
          setAgentUsagePresent(agentRef.present)
          if (instIds.length > 1) {
            console.info(
              `[dashboard] monitor fetch-merge scope=${scopeKey} total=${agentRef.usage.totalMessages} parts=${instIds
                .map((id) => {
                  const u = mergeSessionAgentUsage([id], agentPeriodDays)
                  return `${id}:${u.complete ? u.usage.totalMessages : '?'}`
                })
                .join('+')}`,
            )
          }
        } else {
          // Escopo publicado vazio: evita Carregando… eterno (agentScopeKey '').
          setAgentUsage({ ...EMPTY_AGENT_USAGE, periodDays: agentPeriodDays })
          setAgentUsagePresent(false)
        }
        setAgentScopeKey(`${scopeKey}|${agentPeriodDays}`)
        setAgentUsageLoading(false)

        setLogsFailed(failedHard)
        setLogsError(
          failedHard
            ? errors[0] ?? 'Erro ao carregar métricas dos alunos.'
            : errors.length > 0 && !allReady
              ? `Não foi possível carregar todas as instituições. ${errors[0] ?? ''}`
              : null,
        )
        setLoadingLogs(false)
        initialLogsLoadedRef.current = allReady
        console.info(
          `[dashboard] logs ${Math.round(performance.now() - logsStarted)}ms scope=${scopeKey} ready=${[...ready].join(',')} map=${merged.answerMap.size}`,
        )
      } catch (err) {
        if (cancelled || generation !== logsGenerationRef.current) return
        const msg =
          err instanceof Error
            ? err.message
            : 'Erro ao carregar métricas dos alunos.'
        setLogsError(msg)
        const merged = mergeSessionAnswerMaps(instIds)
        if (merged.readyIds.length === 0) {
          setLogsFailed(true)
          setLogsReadyIds(new Set())
          // Não publica N/A: deixa loading false + erro + tentar de novo.
          setLogAggregates(EMPTY_LOG_AGGREGATES)
          setAgentUsage({ ...EMPTY_AGENT_USAGE, periodDays: agentPeriodDays })
          setAgentUsagePresent(false)
          setAgentScopeKey('')
        } else {
          setLogsReadyIds(new Set(merged.readyIds))
          setLogAggregates({
            doneByStudent: merged.doneByStudent,
            answerMap: merged.answerMap,
          })
          setLogsFailed(false)
        }
        setLoadingLogs(false)
        setAgentUsageLoading(false)
      }
    }

    void run()

    return () => {
      cancelled = true
    }
  }, [selectedIdsKey, activeInstitutionIds, logsRetryKey, agentPeriodDays])

  const sortedInstitutions = useMemo(() => {
    return filterInstitutions(institutions).sort((a, b) => {
      const ma = a.updated_at?.toMillis?.() ?? a.created_at?.toMillis?.() ?? 0
      const mb = b.updated_at?.toMillis?.() ?? b.created_at?.toMillis?.() ?? 0
      return mb - ma
    })
  }, [institutions, filterInstitutions])

  const allActiveTrails = useMemo(() => trails.filter((t) => t.active), [trails])
  const activeTrails = useMemo(
    () => (trailFilter ? allActiveTrails.filter((t) => trailFilter.has(t.id)) : allActiveTrails),
    [allActiveTrails, trailFilter],
  )

  const trailById = useMemo(() => {
    const map = new Map<string, Trail>()
    for (const t of trails) map.set(t.id, t)
    return map
  }, [trails])

  const stageByKey = useMemo(() => {
    const map = new Map<string, TrailStage>()
    for (const s of stages) map.set(`${s.trail_id}|${s.stage_number}`, s)
    return map
  }, [stages])

  const questionByKey = useMemo(() => {
    const map = new Map<string, TrailStageQuestion>()
    for (const q of questions) {
      map.set(`${q.trail_id}|${q.stage_number}|${q.question_number}`, q)
    }
    return map
  }, [questions])

  /**
   * Posições (stage/question) de todas as atividades ativas, por trilha.
   * Não filtra por is_released: uma atividade respondida e bloqueada depois
   * continua contando.
   */
  const questionsByTrail = useMemo(() => {
    const map = new Map<string, { stage: number; question: number }[]>()
    for (const q of questions) {
      if (q.active === false) continue
      const arr = map.get(q.trail_id)
      if (arr) arr.push({ stage: q.stage_number, question: q.question_number })
      else map.set(q.trail_id, [{ stage: q.stage_number, question: q.question_number }])
    }
    return map
  }, [questions])

  /** Atividades de exercício sem gabarito nas trilhas ativas da instituição. */
  const missingGabaritoCount = useMemo(() => {
    const activeIds = new Set(activeTrails.map((t) => t.id))
    let count = 0
    for (const q of questions) {
      if (!activeIds.has(q.trail_id)) continue
      const stage = stageByKey.get(`${q.trail_id}|${q.stage_number}`)
      if (stage?.stage_type !== 'exercise') continue
      if (q.annulled === true) continue
      if (!(q.correct_option ?? '').trim()) count += 1
    }
    return count
  }, [questions, activeTrails, stageByKey])

  /** Atividades de exercício anuladas nas trilhas ativas (visíveis no cálculo). */
  const annulledQuestionKeys = useMemo(() => {
    const activeIds = new Set(activeTrails.map((t) => t.id))
    const keys = new Set<string>()
    for (const q of questions) {
      if (!activeIds.has(q.trail_id)) continue
      if (q.annulled !== true) continue
      const stage = stageByKey.get(`${q.trail_id}|${q.stage_number}`)
      if (stage?.stage_type !== 'exercise') continue
      keys.add(`${q.trail_id}|${q.stage_number}|${q.question_number}`)
    }
    return keys
  }, [questions, activeTrails, stageByKey])

  const annulledGabaritoCount = annulledQuestionKeys.size

  /** Trilhas ativas consideradas nos números da tabela de alunos. */
  const relevantTrails = activeTrails

  /** Stages das trilhas relevantes, para o filtro de seleção (agrupados por trilha). */
  const availableStages = useMemo(() => {
    const relevantIds = new Set(relevantTrails.map((t) => t.id))
    const list = stages
      .filter((s) => relevantIds.has(s.trail_id))
      .map((s) => ({
        key: `${s.trail_id}|${s.stage_number}`,
        trailId: s.trail_id,
        trailName: trailById.get(s.trail_id)?.name || s.trail_id,
        stageNumber: s.stage_number,
        title: s.title,
        stageType: s.stage_type,
      }))
    list.sort((a, b) =>
      a.trailName !== b.trailName
        ? a.trailName.localeCompare(b.trailName, 'pt-BR', {
            sensitivity: 'base',
          })
        : a.stageNumber - b.stageNumber,
    )
    return list
  }, [stages, relevantTrails, trailById])

  const selectedStageCount = useMemo(
    () =>
      availableStages.filter((s) => !deselectedStages.has(s.key)).length,
    [availableStages, deselectedStages],
  )

  /** Números de atividade (q1, q2…) presentes nas trilhas relevantes. */
  const availableQuestions = useMemo(() => {
    const relevantIds = new Set(relevantTrails.map((t) => t.id))
    const nums = new Set<number>()
    for (const q of questions) {
      if (q.active === false) continue
      if (!relevantIds.has(q.trail_id)) continue
      if (q.question_number >= 1) nums.add(q.question_number)
    }
    return [...nums].sort((a, b) => a - b)
  }, [questions, relevantTrails])

  const selectedQuestionCount = useMemo(
    () =>
      availableQuestions.filter((n) => !deselectedQuestions.has(n)).length,
    [availableQuestions, deselectedQuestions],
  )

  const doneQuestionsByStudent = logAggregates.doneByStudent
  const studentAnswerMap = logAggregates.answerMap

  const trailsByStudentIds = useMemo(() => {
    const map = new Map<string, Set<string>>()
    for (const st of studentTrails) {
      let set = map.get(st.student_id)
      if (!set) {
        set = new Set()
        map.set(st.student_id, set)
      }
      set.add(st.trail_id)
    }
    return map
  }, [studentTrails])

  const { enrichedDoneByStudent, forced: forcedCompletions } = useMemo(() => {
    // A regra de conclusão forçada usa a estrutura real da aula (sem filtros
    // de Aulas/Tópicos do dashboard), para não gravar marcador com base em
    // uma "última" posição artificial do filtro.
    return collectForcedCompletions({
      doneByStudent: doneQuestionsByStudent,
      trailsByStudent: trailsByStudentIds,
      questionsByTrail,
      stageByKey,
      deselectedStages: new Set(),
      deselectedQuestions: new Set(),
      institutionId: selectedId || null,
    })
  }, [
    doneQuestionsByStudent,
    trailsByStudentIds,
    questionsByTrail,
    stageByKey,
    selectedId,
  ])

  const forcedCompletionLookup = useMemo(
    () => buildForcedCompletionLookup(forcedCompletions),
    [forcedCompletions],
  )

  const persistedForcedRef = useRef<Set<string>>(new Set())

  useEffect(() => {
    persistedForcedRef.current.clear()
  }, [selectedId])

  useEffect(() => {
    if (!db || forcedCompletions.length === 0) return

    const pending: ForcedCompletionTarget[] = []
    for (const target of forcedCompletions) {
      const id = `${target.studentId}|${target.key}`
      if (persistedForcedRef.current.has(id)) continue
      persistedForcedRef.current.add(id)
      pending.push(target)
    }
    if (pending.length === 0) return

    let cancelled = false
    void (async () => {
      for (const target of pending) {
        if (cancelled) return
        try {
          await upsertForcedCompletionMarker(target)
        } catch (err) {
          console.warn('Falha ao gravar marcador de conclusão forçada', err)
          persistedForcedRef.current.delete(`${target.studentId}|${target.key}`)
        }
      }
    })()

    return () => {
      cancelled = true
    }
  }, [forcedCompletions])

  /**
   * Quantas respostas de alunos estão em atividade anulada e saem do
   * denominador de acerto/erro.
   */
  const annulledAnswersExcluded = useMemo(() => {
    if (annulledQuestionKeys.size === 0) return 0
    let count = 0
    for (const [answerKey, answer] of studentAnswerMap) {
      if (!answer.trim()) continue
      const first = answerKey.indexOf('|')
      if (first < 0) continue
      const qKey = answerKey.slice(first + 1)
      if (annulledQuestionKeys.has(qKey)) count += 1
    }
    return count
  }, [studentAnswerMap, annulledQuestionKeys])

  /**
   * Todas as atividades ativas da trilha (colunas de resposta no XLSX), agrupadas
   * por número da atividade: Q1.S1, Q1.S2, …, Q2.S1, Q2.S2, …
   */
  const allQuestionColumnsByTrail = useMemo(() => {
    const map = new Map<string, { stage: number; question: number }[]>()
    for (const [trailId, positions] of questionsByTrail) {
      map.set(
        trailId,
        [...positions].sort((a, b) =>
          a.question !== b.question
            ? a.question - b.question
            : a.stage - b.stage,
        ),
      )
    }
    return map
  }, [questionsByTrail])

  const activityCatalogs = useMemo(
    () => activityKeysByTrail(questions),
    [questions],
  )

  const activityTotals = useMemo(
    () => activityCountByTrail(questions),
    [questions],
  )

  const studentRows = useMemo<StudentRow[]>(() => {
    const relevantIds = new Set(relevantTrails.map((t) => t.id))

    // Trilhas inscritas de cada aluno, restritas às trilhas ativas/filtradas.
    const trailsByStudent = new Map<string, StudentTrail[]>()
    for (const st of studentTrails) {
      if (!relevantIds.has(st.trail_id)) continue
      const arr = trailsByStudent.get(st.student_id)
      if (arr) arr.push(st)
      else trailsByStudent.set(st.student_id, [st])
    }

    // Atividades por trilha (legado question_number + catálogo stage,question).
    const activitiesByTrail = new Map<string, number[]>()
    const filteredKeysByTrail = new Map<string, ActivityKey[]>()
    for (const trail of relevantTrails) {
      activitiesByTrail.set(
        trail.id,
        trailLessonNumbers(
          trail.id,
          questionsByTrail,
          deselectedStages,
          deselectedQuestions,
        ),
      )
      const catalog = activityCatalogs.get(trail.id) ?? []
      const filtered = catalog.filter((k) => {
        const stageKey = `${trail.id}|${k.stage}`
        if (deselectedStages.has(stageKey)) return false
        if (deselectedQuestions.has(k.question)) return false
        return true
      })
      filteredKeysByTrail.set(trail.id, filtered)
    }

    const metricsReady =
      metricsScopeKey === selectedIdsKey &&
      activeInstitutionIds.every((id) => metricsByInst.has(id))
    const metricsByStudent = new Map<
      string,
      {
        done: number
        released: number
        lessonsDone: number
        lessonsReleased: number
        correct: number
        wrong: number
        accuracyPct: number | null
      }
    >()
    if (metricsReady) {
      for (const id of activeInstitutionIds) {
        const m = metricsByInst.get(id)
        if (!m) continue
        for (const s of m.students) {
          metricsByStudent.set(s.id, {
            done: s.done,
            released: s.released,
            lessonsDone: s.lessonsDone,
            lessonsReleased: s.lessonsReleased,
            correct: s.correct,
            wrong: s.wrong,
            accuracyPct: s.accuracyPct,
          })
        }
      }
    }

    const rows: StudentRow[] = students.map((student) => {
      const enrolled = trailsByStudent.get(student.id) ?? []
      const enrolledTrailIds = new Set(enrolled.map((st) => st.trail_id))
      const progress = progressFromLinks({
        links: enrolled,
        activitiesByTrail,
        activityTotals,
        activityCatalogs,
        activityKeysByTrail: filteredKeysByTrail,
      })
      // Acerto: logs densos (dashboard_summary) têm prioridade; attempts
      // só quando o aluno ainda não tem respostas nos logs.
      const fromAttempts = accuracyFromAttempts(attempts, student.id)
      const fromLogs = scoreStudentFromAnswerMap(
        student.id,
        enrolledTrailIds,
        studentAnswerMap,
        stageByKey,
        questionByKey,
        deselectedStages,
        deselectedQuestions,
      )
      const useLogs = fromLogs.correct + fromLogs.wrong > 0
      const sm = metricsByStudent.get(student.id)
      const correct = useLogs
        ? fromLogs.correct
        : fromAttempts.correct + fromAttempts.wrong > 0
          ? fromAttempts.correct
          : (sm?.correct ?? 0)
      const wrong = useLogs
        ? fromLogs.wrong
        : fromAttempts.correct + fromAttempts.wrong > 0
          ? fromAttempts.wrong
          : (sm?.wrong ?? 0)
      const tried = correct + wrong
      const accuracyPct =
        tried > 0
          ? pct(correct, tried)
          : sm && sm.correct + sm.wrong === 0
            ? null
            : (sm?.accuracyPct ?? null)
      return {
        student,
        released: sm?.released ?? progress.released,
        done: sm?.done ?? progress.done,
        completionPct:
          sm && sm.released > 0
            ? Math.round((sm.done / sm.released) * 1000) / 10
            : progress.completionPct,
        lessonsReleased: sm?.lessonsReleased ?? progress.lessonsReleased,
        lessonsDone: sm?.lessonsDone ?? progress.lessonsDone,
        lessonsCompletionPct:
          sm && sm.lessonsReleased > 0
            ? Math.round((sm.lessonsDone / sm.lessonsReleased) * 1000) / 10
            : progress.lessonsCompletionPct,
        correct,
        wrong,
        accuracyPct,
        engagementStatus: engagementFromLinks(
          enrolled,
          activityTotals,
          activityCatalogs,
        ),
      }
    })

    return rows
  }, [
    students,
    relevantTrails,
    studentTrails,
    questionsByTrail,
    activityTotals,
    activityCatalogs,
    attempts,
    stageByKey,
    questionByKey,
    deselectedStages,
    deselectedQuestions,
    studentAnswerMap,
    metricsScopeKey,
    selectedIdsKey,
    activeInstitutionIds,
    metricsByInst,
  ])

  const filteredStudentRows = useMemo(() => {
    const query = nameFilter.trim().toLowerCase()
    const queryDigits = query.replace(/\D/g, '')
    const lo = Math.min(pctMin, pctMax)
    const hi = Math.max(pctMin, pctMax)
    return studentRows.filter((row) => {
      if (studentPick && !studentPick.has(row.student.id)) return false
      if (query) {
        const nameMatch = row.student.name.toLowerCase().includes(query)
        const phone = (row.student.phone_number ?? '').toLowerCase()
        const phoneDigits = phone.replace(/\D/g, '')
        const phoneMatch =
          phone.includes(query) ||
          (queryDigits.length > 0 && phoneDigits.includes(queryDigits))
        if (!nameMatch && !phoneMatch) return false
      }
      const p = row.completionPct ?? 0
      if (p < lo || p > hi) return false
      return true
    })
  }, [studentRows, nameFilter, pctMin, pctMax, studentPick])

  const chartFilteredStudentRows = useMemo(() => {
    if (!studentChartFilter) return filteredStudentRows

    if (studentChartFilter.kind === 'status') {
      return filteredStudentRows.filter(
        (row) => getStudentEngagementStatus(row) === studentChartFilter.key,
      )
    }

    if (studentChartFilter.kind === 'completion') {
      return filteredStudentRows.filter(
        (row) =>
          getCompletionBucketKey(row.completionPct) === studentChartFilter.key,
      )
    }

    const selectedLessonKeys = new Set(studentChartFilter.keys)
    const topicsByLessonKey = new Map<string, TopicPosition[]>()
    for (const key of selectedLessonKeys) {
      const sep = key.lastIndexOf('|')
      if (sep < 0) continue
      const trailId = key.slice(0, sep)
      const lessonNumber = Number(key.slice(sep + 1))
      if (!Number.isFinite(lessonNumber)) continue
      const topics =
        groupTopicsByLesson(
          filterTrailTopicPositions(
            trailId,
            questionsByTrail.get(trailId) ?? [],
            deselectedStages,
            deselectedQuestions,
          ),
        ).get(lessonNumber) ?? []
      topicsByLessonKey.set(key, topics)
    }

    return filteredStudentRows.filter((row) => {
      const enrolled = trailsByStudentIds.get(row.student.id)
      if (!enrolled) return false
      const studentDone = enrichedDoneByStudent.get(row.student.id) ?? new Set()
      for (const [lessonKey, topics] of topicsByLessonKey) {
        const trailId = lessonKey.slice(0, lessonKey.lastIndexOf('|'))
        if (!enrolled.has(trailId)) continue
        if (isLessonCompleteForTrail(trailId, topics, studentDone)) return true
      }
      return false
    })
  }, [
    filteredStudentRows,
    studentChartFilter,
    questionsByTrail,
    deselectedStages,
    deselectedQuestions,
    trailsByStudentIds,
    enrichedDoneByStudent,
  ])

  const sortedFilteredStudentRows = useMemo(() => {
    const rows = [...chartFilteredStudentRows]
    const { key, dir } = studentSort
    const mult = dir === 'asc' ? 1 : -1
    rows.sort((a, b) => {
      let cmp = 0
      switch (key) {
        case 'name':
          cmp = (a.student.name || '').localeCompare(
            b.student.name || '',
            'pt-BR',
            { sensitivity: 'base' },
          )
          break
        case 'phone':
          cmp = (a.student.phone_number || '').localeCompare(
            b.student.phone_number || '',
            'pt-BR',
            { sensitivity: 'base' },
          )
          break
        case 'released':
          cmp = a.released - b.released
          break
        case 'done':
          cmp = a.done - b.done
          break
        case 'completionPct':
          cmp = compareNullableNumber(a.completionPct, b.completionPct)
          break
        case 'lessonsReleased':
          cmp = a.lessonsReleased - b.lessonsReleased
          break
        case 'lessonsDone':
          cmp = a.lessonsDone - b.lessonsDone
          break
        case 'lessonsCompletionPct':
          cmp = compareNullableNumber(a.lessonsCompletionPct, b.lessonsCompletionPct)
          break
        case 'correct':
          cmp = a.correct - b.correct
          break
        case 'wrong':
          cmp = a.wrong - b.wrong
          break
        case 'accuracyPct':
          cmp = compareNullableNumber(a.accuracyPct, b.accuracyPct)
          break
      }
      return cmp * mult
    })
    return rows
  }, [chartFilteredStudentRows, studentSort])

  const studentPageCount = useMemo(
    () =>
      Math.max(1, Math.ceil(sortedFilteredStudentRows.length / STUDENTS_PAGE_SIZE)),
    [sortedFilteredStudentRows.length],
  )

  const paginatedStudentRows = useMemo(() => {
    const start = (studentPage - 1) * STUDENTS_PAGE_SIZE
    return sortedFilteredStudentRows.slice(start, start + STUDENTS_PAGE_SIZE)
  }, [sortedFilteredStudentRows, studentPage])

  useEffect(() => {
    setStudentPage(1)
  }, [selectedId, nameFilter, pctMin, pctMax, studentChartFilter])

  useEffect(() => {
    if (studentPage > studentPageCount) {
      setStudentPage(studentPageCount)
    }
  }, [studentPage, studentPageCount])

  const studentPageRange = useMemo(() => {
    if (sortedFilteredStudentRows.length === 0) {
      return { start: 0, end: 0 }
    }
    const start = (studentPage - 1) * STUDENTS_PAGE_SIZE + 1
    const end = Math.min(
      studentPage * STUDENTS_PAGE_SIZE,
      sortedFilteredStudentRows.length,
    )
    return { start, end }
  }, [sortedFilteredStudentRows.length, studentPage])

  // Cards de resumo — mesma definição de acerto do Início (acertoMedio).
  const summary = useMemo(() => {
    const activeRows = filteredStudentRows.filter((r) => r.student.active)

    let doneTotal = 0
    let releasedTotal = 0
    let lessonsDoneTotal = 0
    let lessonsReleasedTotal = 0
    for (const row of activeRows) {
      doneTotal += row.done
      releasedTotal += row.released
      lessonsDoneTotal += row.lessonsDone
      lessonsReleasedTotal += row.lessonsReleased
    }

    const avgCompletion =
      releasedTotal > 0
        ? Math.round((doneTotal / releasedTotal) * 1000) / 10
        : null

    const avgLessonCompletion =
      lessonsReleasedTotal > 0
        ? Math.round((lessonsDoneTotal / lessonsReleasedTotal) * 1000) / 10
        : null

    // Preferir métricas pré-agregadas (sem meta local / sem 57k answers).
    // Contagens: basta ter o doc de cada id ativo (não espera scopeKey) —
    // evita 2–5s de Carregando… no retorno Início→Dados / troca de inst.
    const hasMetricsForActive = activeInstitutionIds.every((id) =>
      metricsByInst.has(id),
    )
    const metricsReady =
      metricsScopeKey === selectedIdsKey && hasMetricsForActive
    const metricsParts = hasMetricsForActive
      ? activeInstitutionIds
          .map((id) => metricsByInst.get(id))
          .filter((m): m is InstitutionDashboardMetricsView => Boolean(m))
      : []
    const mergedMetrics =
      metricsParts.length > 0 ? mergeMetricsViews(metricsParts) : null
    // Só publica % se o escopo da map bate (evita flash da inst anterior).
    const publishMerged = metricsReady && mergedMetrics

    const metaReady =
      metricsReady ||
      (!loadingMeta && questions.length > 0 && stages.length > 0)
    const gate = dashboardAccuracyGate({
      selectedIdsKey,
      selectedIds: activeInstitutionIds,
      dataScopeKey: metricsReady ? selectedIdsKey : dataScopeKey,
      loadingData: metricsReady ? false : loadingData,
      metaReady,
      logsReadyIds: metricsReady
        ? new Set(activeInstitutionIds)
        : logsReadyIds,
      loadingLogs: metricsReady ? false : loadingLogs,
      logsFailed,
    })
    const activeIds = new Set(activeRows.map((r) => r.student.id))
    const allTrailIds = new Set(trails.map((t) => t.id))
    let avgAccuracy: number | null = null
    if (publishMerged) {
      avgAccuracy = mergedMetrics.avgAccuracy
    } else if (gate.canPublishAccuracy && studentAnswerMap.size > 0) {
      const { gabarito, annulled } = gabaritoFromQuestions(questions)
      const answers = mergeAnswerSources(
        answersFromAnswerMap(studentAnswerMap),
        answersFromAttempts(attempts),
      )
      avgAccuracy = accuracyAggregate({
        activeStudentIds: activeIds,
        answers,
        gabarito,
        annulled,
        trailIds: allTrailIds.size > 0 ? allTrailIds : undefined,
      }).avgAccuracy
    }

    // Sem métricas do escopo atual: Carregando… (nunca % da instituição anterior).
    const completionLoading = !metricsReady || gate.avgAccuracyLoading
    const countsLoading = !hasMetricsForActive
    return {
      activeStudents: hasMetricsForActive
        ? (mergedMetrics?.activeStudents ?? activeRows.length)
        : activeRows.length,
      activeTrails: hasMetricsForActive
        ? (mergedMetrics?.activeTrails ?? activeTrails.length)
        : activeTrails.length,
      avgCompletion: publishMerged
        ? (mergedMetrics.avgCompletion ?? avgCompletion)
        : metricsReady
          ? avgCompletion
          : null,
      avgLessonCompletion: publishMerged
        ? (mergedMetrics.avgLessonCompletion ?? avgLessonCompletion)
        : metricsReady
          ? avgLessonCompletion
          : null,
      avgAccuracy: metricsReady ? avgAccuracy : null,
      avgAccuracyLoading: !metricsReady || gate.avgAccuracyLoading,
      completionLoading,
      countsLoading,
      inactiveStudents: students.filter(
        (st) => !st.active && activeInstitutionIds.includes(st.institution_id),
      ).length,
    }
  }, [
    students,
    filteredStudentRows,
    activeTrails,
    dataScopeKey,
    logsReadyIds,
    logsFailed,
    selectedIdsKey,
    activeInstitutionIds,
    loadingData,
    loadingMeta,
    loadingLogs,
    trails,
    stages,
    attempts,
    questions,
    studentAnswerMap,
    metricsByInst,
    metricsScopeKey,
  ])

  const studentsCharts = useMemo(() => {
    const metricsReady =
      metricsScopeKey === selectedIdsKey &&
      activeInstitutionIds.every((id) => metricsByInst.has(id))
    // Após F5: métricas/linhas ainda não chegaram → Carregando… (nunca 0).
    const chartsLoading =
      !metricsReady ||
      (filteredStudentRows.length === 0 &&
        (loadingData || !hasDashboardContent))

    const completionBuckets = [
      { key: '0-20', label: '0-20%', count: 0 },
      { key: '21-40', label: '21-40%', count: 0 },
      { key: '41-60', label: '41-60%', count: 0 },
      { key: '61-80', label: '61-80%', count: 0 },
      { key: '81-100', label: '81-100%', count: 0 },
    ]
    const statusCounts = {
      notStarted: 0,
      inProgress: 0,
      completed: 0,
    }

    const bumpCompletion = (completion: number | null) => {
      if (completion === null) return
      if (completion <= 20) completionBuckets[0].count += 1
      else if (completion <= 40) completionBuckets[1].count += 1
      else if (completion <= 60) completionBuckets[2].count += 1
      else if (completion <= 80) completionBuckets[3].count += 1
      else completionBuckets[4].count += 1
    }

    if (filteredStudentRows.length > 0) {
      for (const row of filteredStudentRows) {
        statusCounts[getStudentEngagementStatus(row)] += 1
        bumpCompletion(row.completionPct)
      }
    } else if (metricsReady) {
      // Sem linhas locais ainda: faixas a partir do doc de métricas.
      for (const id of activeInstitutionIds) {
        const m = metricsByInst.get(id)
        if (!m) continue
        for (const s of m.students) {
          if (!s.active) continue
          const completion =
            s.released > 0
              ? Math.round((s.done / s.released) * 1000) / 10
              : null
          bumpCompletion(completion)
          if (s.released <= 0 || s.done <= 0) statusCounts.notStarted += 1
          else if (s.done >= s.released) statusCounts.completed += 1
          else statusCounts.inProgress += 1
        }
      }
    }

    const multiTrail = relevantTrails.length > 1
    const multiInst = activeInstitutionIds.length > 1
    const instNameById = new Map(
      institutions.map((i) => [i.id, (i.name || i.id).trim()]),
    )
    function shortTag(name: string, id: string): string {
      const raw = (name || id).trim()
      const letters = raw.replace(/[^A-Za-zÀ-ÿ0-9]/g, '')
      if (letters.length >= 3) return letters.slice(0, 3)
      return (id.replace(/^i/i, '').replace(/^t/i, 'T') || 'X').slice(0, 3)
    }
    /** Prefixo curto da trilha para eixo multi-trilha (ex.: Aurora → Aur). */
    function trailShortTag(name: string, id: string): string {
      return shortTag(name, id)
    }
    function instShortTag(institutionId: string): string {
      return shortTag(
        instNameById.get(institutionId) ?? institutionId,
        institutionId,
      )
    }
    const lessonBars: {
      key: string
      label: string
      fullLabel?: string
      lessonNumber: number
      count: number
      enrolledCount: number
    }[] = []

    // Índice rápido: vínculo aluno-trilha (fonte Início).
    const linkByStudentTrail = new Map<string, StudentTrail>()
    for (const st of studentTrails) {
      linkByStudentTrail.set(`${st.student_id}|${st.trail_id}`, st)
    }

    for (const trail of relevantTrails) {
      const catalog = (activityCatalogs.get(trail.id) ?? []).filter((k) => {
        const stageKey = `${trail.id}|${k.stage}`
        if (deselectedStages.has(stageKey)) return false
        if (deselectedQuestions.has(k.question)) return false
        return true
      })
      const trailLabel = (trail.name || trail.id).trim()
      const tag = trailShortTag(trailLabel, trail.id)
      const stages = [...new Set(catalog.map((k) => k.stage))].sort(
        (a, b) => a - b,
      )

      // Com muitas atividades (ex.: 12×100), agrega por etapa (E1..En).
      // Com poucas, mostra E{n} A{m} (stage, question).
      const aggregateByStage = catalog.length > 40 || stages.length > 1

      if (aggregateByStage) {
        for (const stage of stages) {
          let enrolledCount = 0
          let count = 0
          for (const row of filteredStudentRows) {
            const enrolled = trailsByStudentIds.get(row.student.id)
            if (!enrolled?.has(trail.id)) continue
            enrolledCount += 1
            const link = linkByStudentTrail.get(
              `${row.student.id}|${trail.id}`,
            )
            if (link && isStageDoneOnLink(link, stage, catalog)) {
              count += 1
            }
          }
          // Multi-instituição: Inst·E1 (evita "Pro E10Pro E11" colado).
          // Multi-trilha: Tag·E1. Uma trilha: E1…En.
          const instTag = instShortTag(trail.institution_id)
          const label = multiInst
            ? `${instTag}\nE${stage}`
            : multiTrail
              ? `${tag}\nE${stage}`
              : `E${stage}`
          const fullLabel = multiInst
            ? `${instNameById.get(trail.institution_id) ?? trail.institution_id} · Etapa ${stage} · ${trailLabel}`
            : multiTrail
              ? `Etapa ${stage} · ${trailLabel}`
              : `Etapa ${stage}`
          lessonBars.push({
            key: `${trail.id}|E${stage}`,
            label,
            fullLabel,
            lessonNumber: stage,
            count,
            enrolledCount,
          })
        }
        continue
      }

      for (const activity of catalog) {
        let enrolledCount = 0
        let count = 0
        for (const row of filteredStudentRows) {
          const enrolled = trailsByStudentIds.get(row.student.id)
          if (!enrolled?.has(trail.id)) continue
          enrolledCount += 1
          const link = linkByStudentTrail.get(`${row.student.id}|${trail.id}`)
          if (link && isActivityKeyDoneOnLink(link, activity, catalog)) {
            count += 1
          }
        }
        const short = `E${activity.stage}A${activity.question}`
        const instTag = instShortTag(trail.institution_id)
        const label = multiInst
          ? `${instTag}\n${short}`
          : multiTrail
            ? `${tag}\n${short}`
            : short
        lessonBars.push({
          key: `${trail.id}|${activity.stage}|${activity.question}`,
          label,
          fullLabel: multiInst
            ? `${instNameById.get(trail.institution_id) ?? trail.institution_id} · Etapa ${activity.stage} · Atividade ${activity.question} · ${trailLabel}`
            : multiTrail
              ? `Etapa ${activity.stage} · Atividade ${activity.question} · ${trailLabel}`
              : `Etapa ${activity.stage} · Atividade ${activity.question}`,
          lessonNumber: activity.question,
          count,
          enrolledCount,
        })
      }
    }

    return {
      studentCount: filteredStudentRows.length,
      loading: chartsLoading,
      completionBuckets,
      statuses: [
        {
          key: 'notStarted' as const,
          label: 'Não iniciou',
          count: statusCounts.notStarted,
        },
        {
          key: 'inProgress' as const,
          label: 'Em andamento',
          count: statusCounts.inProgress,
        },
        {
          key: 'completed' as const,
          label: 'Concluiu (100%)',
          count: statusCounts.completed,
        },
      ],
      lessonBars: chartsLoading ? [] : lessonBars,
    }
  }, [
    filteredStudentRows,
    relevantTrails,
    activeInstitutionIds,
    institutions,
    deselectedStages,
    deselectedQuestions,
    trailsByStudentIds,
    studentTrails,
    activityCatalogs,
    metricsScopeKey,
    selectedIdsKey,
    metricsByInst,
    loadingData,
    hasDashboardContent,
  ])

  // Ranking de pílulas — itera só respostas existentes no mapa.
  // Sempre calcula (aba + Menor/Maior + contador); não depende do tab Exercícios.
  const gradablePillQuestions = useMemo(() => {
    const map = new Map<string, string>()

    for (const trail of activeTrails) {
      const positions = questionsByTrail.get(trail.id) ?? []
      for (const p of positions) {
        const stage = stageByKey.get(`${trail.id}|${p.stage}`)
        if (stage?.stage_type !== 'exercise') continue

        const key = `${trail.id}|${p.stage}|${p.question}`
        const question = questionByKey.get(key)
        if (question?.annulled === true) continue
        const gabarito = (question?.correct_option ?? '').trim()
        if (!gabarito) continue
        map.set(key, gabarito)
      }
    }
    return map
  }, [activeTrails, questionsByTrail, stageByKey, questionByKey])

  const pillRows = useMemo<PillRow[]>(() => {
    // Caminho rápido: pills pré-agregados (340 na Sol) — sem varrer answerMap.
    if (
      metricsScopeKey === selectedIdsKey &&
      activeInstitutionIds.every((id) => metricsByInst.has(id))
    ) {
      const rows: PillRow[] = []
      for (const id of activeInstitutionIds) {
        const m = metricsByInst.get(id)
        if (!m) continue
        for (const p of m.exercisePills) {
          rows.push({
            exerciseLabel: `Exercício`,
            statement: '',
            alternatives: [],
            key: `${id}|${p.key}`,
            trailId: p.trailId,
            trailName: p.trailName,
            subject: 'N/A',
            stageNumber: p.stageNumber,
            questionNumber: p.questionNumber,
            title: p.title,
            content: '',
            gabarito: p.gabarito,
            total: p.total,
            correct: p.correct,
            wrong: p.wrong,
            accuracyPct: p.accuracyPct,
          })
        }
      }
      return rows
    }

    const byKey = new Map<string, { correct: number; wrong: number; picks: Map<string, number> }>()

    for (const [answerKey, answer] of studentAnswerMap) {
      if (!answer.trim()) continue

      const parts = answerKey.split('|')
      if (parts.length !== 4) continue

      const qKey = `${parts[1]}|${parts[2]}|${parts[3]}`
      const gabarito = gradablePillQuestions.get(qKey)
      if (!gabarito) continue

      let agg = byKey.get(qKey)
      if (!agg) {
        agg = { correct: 0, wrong: 0, picks: new Map() }
        byKey.set(qKey, agg)
      }
      const pickedLetter = correctToLetter(answer)
      if (pickedLetter) agg.picks.set(pickedLetter, (agg.picks.get(pickedLetter) ?? 0) + 1)

      if (answersMatch(answer, gabarito)) agg.correct += 1
      else agg.wrong += 1
    }

    const rows: PillRow[] = []
    for (const [key, agg] of byKey) {
      const [trailId, stageStr, questionStr] = key.split('|')
      const stageNumber = Number(stageStr)
      const questionNumber = Number(questionStr)
      const trail = trailById.get(trailId)
      const question = questionByKey.get(key)
      const total = agg.correct + agg.wrong
      if (total < 1) continue
      const resolved = resolveExerciseOptions(question?.content ?? '', question?.options ?? null)
      const rightLetter = correctToLetter(
        gradablePillQuestions.get(key) ?? question?.correct_option ?? '',
      )
      const alternatives = (resolved.options ?? []).map((o, i) => {
        const letter = o.key && /^[A-Za-z]$/.test(o.key) ? o.key.toUpperCase() : letterOf(i)
        return {
          key: letter,
          text: o.label.replace(new RegExp(`^${o.key}\\s*[).:\\-–—]\\s*`, 'i'), '').trim(),
          count: agg.picks.get(letter) ?? 0,
          correct: letter === rightLetter,
        }
      })
      const exerciseStages = stages
        .filter((st) => st.trail_id === trailId && st.stage_type === 'exercise')
        .map((st) => st.stage_number)
        .sort((a, b) => a - b)
      const exerciseIndex = exerciseStages.indexOf(stageNumber)
      rows.push({
        exerciseLabel:
          exerciseIndex >= 0 ? `Exercício ${exerciseIndex + 1} de ${exerciseStages.length}` : 'Exercício',
        statement: resolved.displayBody,
        alternatives,
        key,
        trailId,
        trailName: trail?.name || trailId,
        subject: trail?.subject?.trim() || 'N/A',
        stageNumber,
        questionNumber,
        title: question?.title || 'N/A',
        content: question?.content ?? '',
        gabarito: formatGabaritoLetter(
          gradablePillQuestions.get(key) ??
            question?.correct_option ??
            '',
        ),
        total,
        correct: agg.correct,
        wrong: agg.wrong,
        accuracyPct: Math.round((agg.correct / total) * 100),
      })
    }
    return rows
  }, [
    studentAnswerMap,
    gradablePillQuestions,
    trailById,
    questionByKey,
    stages,
    metricsScopeKey,
    selectedIdsKey,
    activeInstitutionIds,
    metricsByInst,
  ])

  const filteredPillRows = useMemo(() => {
    const query = pillSearch.trim().toLowerCase()
    const lo = Math.min(pillAccMin, pillAccMax)
    const hi = Math.max(pillAccMin, pillAccMax)
    return pillRows.filter((row) => {
      if (row.total < pillMinResponses) return false
      if (pillTrailFilter && row.trailId !== pillTrailFilter) return false
      if (row.accuracyPct < lo || row.accuracyPct > hi) return false
      if (query) {
        const code = `t${row.stageNumber} a${row.questionNumber}`
        const haystack = [
          row.title,
          row.content,
          row.trailName,
          row.subject,
          row.gabarito,
          code,
          `t${row.stageNumber}`,
          `a${row.questionNumber}`,
        ]
          .join(' ')
          .toLowerCase()
        if (!haystack.includes(query)) return false
      }
      return true
    })
  }, [
    pillRows,
    pillSearch,
    pillTrailFilter,
    pillMinResponses,
    pillAccMin,
    pillAccMax,
  ])

  const sortedPillRows = useMemo(() => {
    const rows = [...filteredPillRows]
    const { key, dir } = pillSort
    const mult = dir === 'asc' ? 1 : -1
    rows.sort((a, b) => {
      let cmp = 0
      switch (key) {
        case 'trail':
          cmp = a.trailName.localeCompare(b.trailName, 'pt-BR', {
            sensitivity: 'base',
          })
          break
        case 'position':
          cmp =
            a.stageNumber !== b.stageNumber
              ? a.stageNumber - b.stageNumber
              : a.questionNumber - b.questionNumber
          break
        case 'total':
          cmp = a.total - b.total
          break
        case 'correct':
          cmp = a.correct - b.correct
          break
        case 'wrong':
          cmp = a.wrong - b.wrong
          break
        case 'accuracyPct':
          cmp = a.accuracyPct - b.accuracyPct
          break
      }
      return cmp * mult
    })
    return rows
  }, [filteredPillRows, pillSort])

  const worstPills = useMemo(
    () =>
      [...filteredPillRows]
        .sort((a, b) => a.accuracyPct - b.accuracyPct)
        .slice(0, 5),
    [filteredPillRows],
  )
  const bestPills = useMemo(
    () =>
      [...filteredPillRows]
        .sort((a, b) => b.accuracyPct - a.accuracyPct)
        .slice(0, 5),
    [filteredPillRows],
  )

  const questionsCharts = useMemo(() => {
    let correctTotal = 0
    let wrongTotal = 0
    const filteredQuestionKeys = new Set(
      filteredPillRows.map((row) => row.key),
    )
    const studentIds = new Set<string>()
    const buckets = [
      { label: '0-20%', count: 0 },
      { label: '21-40%', count: 0 },
      { label: '41-60%', count: 0 },
      { label: '61-80%', count: 0 },
      { label: '81-100%', count: 0 },
    ]
    const byTrail = new Map<
      string,
      { label: string; responses: number; weightedAcc: number }
    >()

    for (const row of filteredPillRows) {
      correctTotal += row.correct
      wrongTotal += row.wrong
      if (row.accuracyPct <= 20) buckets[0].count += 1
      else if (row.accuracyPct <= 40) buckets[1].count += 1
      else if (row.accuracyPct <= 60) buckets[2].count += 1
      else if (row.accuracyPct <= 80) buckets[3].count += 1
      else buckets[4].count += 1

      const trail = byTrail.get(row.trailId)
      if (trail) {
        trail.responses += row.total
        trail.weightedAcc += row.accuracyPct * row.total
      } else {
        byTrail.set(row.trailId, {
          label: row.trailName,
          responses: row.total,
          weightedAcc: row.accuracyPct * row.total,
        })
      }
    }

    for (const [answerKey, answer] of studentAnswerMap) {
      if (!answer.trim()) continue
      const parts = answerKey.split('|')
      if (parts.length !== 4) continue
      const studentId = parts[0]
      const questionKey = `${parts[1]}|${parts[2]}|${parts[3]}`
      if (filteredQuestionKeys.has(questionKey)) studentIds.add(studentId)
    }

    const responseCount = correctTotal + wrongTotal
    const trailBars = [...byTrail.entries()]
      .map(([id, t]) => ({
        id,
        label: t.label,
        responses: t.responses,
        avgAccuracy:
          t.responses > 0 ? Math.round(t.weightedAcc / t.responses) : 0,
      }))
      .sort((a, b) => b.responses - a.responses)
      .slice(0, 8)

    return {
      studentCount: studentIds.size,
      questionCount: filteredPillRows.length,
      responseCount,
      avgAccuracy: pct(correctTotal, responseCount),
      correctTotal,
      wrongTotal,
      accuracyBuckets: buckets,
      trailBars,
    }
  }, [filteredPillRows, studentAnswerMap])

  const pillPageCount = useMemo(
    () => Math.max(1, Math.ceil(sortedPillRows.length / PILLS_PAGE_SIZE)),
    [sortedPillRows.length],
  )

  const paginatedPillRows = useMemo(() => {
    const start = (pillPage - 1) * PILLS_PAGE_SIZE
    return sortedPillRows.slice(start, start + PILLS_PAGE_SIZE)
  }, [sortedPillRows, pillPage])

  const pillPageRange = useMemo(() => {
    if (sortedPillRows.length === 0) return { start: 0, end: 0 }
    const start = (pillPage - 1) * PILLS_PAGE_SIZE + 1
    const end = Math.min(pillPage * PILLS_PAGE_SIZE, sortedPillRows.length)
    return { start, end }
  }, [sortedPillRows.length, pillPage])

  useEffect(() => {
    setPillPage(1)
  }, [
    selectedId,
    pillSearch,
    pillTrailFilter,
    pillMinResponses,
    pillAccMin,
    pillAccMax,
  ])

  useEffect(() => {
    if (pillPage > pillPageCount) setPillPage(pillPageCount)
  }, [pillPage, pillPageCount])

  const pillExportTrails = useMemo(() => {
    if (!pillTrailFilter) return activeTrails
    return activeTrails.filter((t) => t.id === pillTrailFilter)
  }, [activeTrails, pillTrailFilter])

  const pillTrailOptions = useMemo(() => {
    const byId = new Map<string, string>()
    for (const row of pillRows) {
      byId.set(row.trailId, row.trailName)
    }
    return [...byId.entries()]
      .map(([id, label]) => ({ id, label }))
      .sort((a, b) =>
        a.label.localeCompare(b.label, 'pt-BR', { sensitivity: 'base' }),
      )
  }, [pillRows])

  function togglePillSort(key: PillSortKey) {
    setPillSort((curr) =>
      curr.key === key
        ? { key, dir: curr.dir === 'asc' ? 'desc' : 'asc' }
        : { key, dir: key === 'accuracyPct' ? 'asc' : 'desc' },
    )
  }

  function toggleStudentSort(key: StudentSortKey) {
    setStudentSort((curr) =>
      curr.key === key
        ? { key, dir: curr.dir === 'asc' ? 'desc' : 'asc' }
        : {
            key,
            dir: key === 'name' || key === 'phone' ? 'asc' : 'desc',
          },
    )
  }

  function pillSortIndicator(key: PillSortKey): string {
    if (pillSort.key !== key) return ''
    return pillSort.dir === 'asc' ? ' ↑' : ' ↓'
  }

  function studentSortIndicator(key: StudentSortKey): string {
    if (studentSort.key !== key) return ''
    return studentSort.dir === 'asc' ? ' ↑' : ' ↓'
  }

  function computeTrailMetrics(
    studentId: string,
    trailId: string,
    doneOverride?: Map<string, Set<string>>,
  ): { released: number; done: number; completionPct: number | null } {
    const enrolled = studentTrails.some(
      (st) => st.student_id === studentId && st.trail_id === trailId,
    )
    if (!enrolled) {
      return { released: 0, done: 0, completionPct: null }
    }

    const positions = questionsByTrail.get(trailId) ?? []
    const selected = positions.filter(
      (p) =>
        !deselectedStages.has(`${trailId}|${p.stage}`) &&
        !deselectedQuestions.has(p.question),
    )
    const studentDone =
      doneOverride?.get(studentId) ??
      enrichedDoneByStudent.get(studentId) ??
      new Set()
    let done = 0
    for (const p of selected) {
      const key = `${trailId}|${p.stage}|${p.question}`
      if (studentDone.has(key)) done += 1
    }
    const released = selected.length
    return { released, done, completionPct: pct(done, released) }
  }

  async function exportTrailHistoryXlsx(trailId: string) {
    const trail = trailById.get(trailId)
    if (!db || !trail || exportingTrailId) return
    setExportError(null)
    setExportingTrailId(trail.id)
    try {
      const xlsx = await loadXlsx()

      // Dá tempo para o navegador renderizar o estado "Gerando…" antes do
      // processamento síncrono do XLSX bloquear a thread principal.
      await new Promise<void>((resolve) => {
        window.requestAnimationFrame(() => {
          window.requestAnimationFrame(() => resolve())
        })
      })

      // Reutiliza os agregados já carregados no dashboard (mesmos alunos e
      // trilhas da instituição), sem refazer o download de logs.
      const answersByKey = studentAnswerMap
      const exportDoneByStudent = enrichedDoneByStudent
      const forcedLookup = forcedCompletionLookup

      const answerColumns = (
        allQuestionColumnsByTrail.get(trail.id) ?? []
      ).filter(
        (p) =>
          !deselectedStages.has(`${trail.id}|${p.stage}`) &&
          !deselectedQuestions.has(p.question),
      )
      const fixedHeaders = [
        'Nome',
        'Telefone',
        'Atividades liberadas',
        'Atividades feitas',
        '% conclusão (atividades)',
        'Etapas liberadas',
        'Etapas feitas',
        '% conclusão (etapas)',
      ]
      const headers = [
        ...fixedHeaders,
        ...answerColumns.map((p) =>
          activityStageLabel(trail.id, p.stage, p.question, stageByKey),
        ),
      ]

      // Exporta todas as linhas que correspondem aos filtros atuais, não
      // apenas os 20 alunos da página visível.
      const sortedStudents = sortedFilteredStudentRows.map((row) => row.student)

      const rows = sortedStudents.map((student) => {
        const metrics = computeTrailMetrics(
          student.id,
          trail.id,
          exportDoneByStudent,
        )
        const lessons = computeLessonMetricsForTrails(
          [trail.id],
          questionsByTrail,
          exportDoneByStudent.get(student.id) ?? new Set<string>(),
          deselectedStages,
          deselectedQuestions,
        )
        const row: (string | number)[] = [
          student.name || student.id,
          student.phone_number || '',
          lessons.lessonsReleased,
          lessons.lessonsDone,
          formatPctExport(lessons.lessonsCompletionPct),
          metrics.released,
          metrics.done,
          formatPctExport(metrics.completionPct),
        ]
        for (const p of answerColumns) {
          const answerKey = `${student.id}|${trail.id}|${p.stage}|${p.question}`
          const answer = answersByKey.get(answerKey)
          if (answer?.trim()) {
            row.push(answer)
          } else if (
            forcedLookup.has(
              `${student.id}|${trail.id}|${p.stage}|${p.question}`,
            )
          ) {
            row.push(FORCED_COMPLETION_EXPORT_TOPIC_LABEL)
          } else {
            row.push('')
          }
        }
        return row
      })

      const worksheet = xlsx.utils.aoa_to_sheet([headers, ...rows])
      const fixedColCount = fixedHeaders.length

      headers.forEach((header, colIndex) => {
        forceWorksheetCellString(xlsx, worksheet, 0, colIndex, header)
      })

      rows.forEach((row, rowIndex) => {
        for (let colIndex = fixedColCount; colIndex < headers.length; colIndex++) {
          const value = row[colIndex]
          if (typeof value === 'string' && value.length > 0) {
            forceWorksheetCellString(xlsx, worksheet, rowIndex + 1, colIndex, value)
          }
        }
      })

      const workbook = xlsx.utils.book_new()
      xlsx.utils.book_append_sheet(workbook, worksheet, 'Histórico')
      appendCorrespondenceSheet(
        xlsx,
        workbook,
        trail.id,
        answerColumns,
        stageByKey,
        questionByKey,
      )
      appendLessonsProgressSheet(
        xlsx,
        workbook,
        trail,
        sortedStudents,
        questionsByTrail,
        exportDoneByStudent,
        deselectedStages,
        deselectedQuestions,
        forcedLookup,
      )
      const trailSlug = slugFileName(trail.name || trail.id)
      xlsx.writeFile(workbook, `historico-alunos-${trailSlug}.xlsx`)
    } catch (err) {
      setExportError(
        err instanceof Error ? err.message : 'Erro ao gerar planilha.',
      )
    } finally {
      setExportingTrailId(null)
    }
  }

  async function exportPillTrailXlsx(trailId: string) {
    const trail = trailById.get(trailId)
    if (!trail || exportingPillTrailId) return
    setExportError(null)
    setExportingPillTrailId(trail.id)
    try {
      const xlsx = await loadXlsx()
      const rows = sortedPillRows.filter((p) => p.trailId === trail.id)
      const headers = [
        'Trilha',
        'Matéria',
        'Atividade · Etapa',
        'Título',
        'Enunciado',
        'Gabarito',
        'Respostas',
        'Acertos',
        'Erros',
        '% acerto',
      ]
      const data = rows.map((p) => [
        p.trailName,
        p.subject,
        activityStageLabel(
          p.trailId,
          p.stageNumber,
          p.questionNumber,
          stageByKey,
        ),
        p.title,
        p.content.trim() || p.title.trim(),
        p.gabarito,
        p.total,
        p.correct,
        p.wrong,
        `${p.accuracyPct}%`,
      ])

      const worksheet = xlsx.utils.aoa_to_sheet([headers, ...data])
      headers.forEach((header, colIndex) => {
        forceWorksheetCellString(xlsx, worksheet, 0, colIndex, header)
      })
      data.forEach((row, rowIndex) => {
        const enunciado = row[4]
        if (typeof enunciado === 'string' && enunciado.length > 0) {
          forceWorksheetCellString(xlsx, worksheet, rowIndex + 1, 4, enunciado)
        }
        const gabarito = row[5]
        if (typeof gabarito === 'string' && gabarito.length > 0) {
          forceWorksheetCellString(xlsx, worksheet, rowIndex + 1, 5, gabarito)
        }
      })

      const workbook = xlsx.utils.book_new()
      xlsx.utils.book_append_sheet(workbook, worksheet, 'Atividades')
      const correspondencePositions =
        allQuestionColumnsByTrail.get(trail.id) ?? []
      if (correspondencePositions.length > 0) {
        appendCorrespondenceSheet(
          xlsx,
          workbook,
          trail.id,
          correspondencePositions,
          stageByKey,
          questionByKey,
        )
      }
      const trailSlug = slugFileName(trail.name || trail.id)
      xlsx.writeFile(workbook, `atividades-acertos-erros-${trailSlug}.xlsx`)
    } catch (err) {
      setExportError(
        err instanceof Error ? err.message : 'Erro ao gerar planilha.',
      )
    } finally {
      setExportingPillTrailId(null)
    }
  }

  const visibleColumns = ALL_STUDENT_COLUMNS.filter(
    (c) => !hiddenColumns.has(c.key),
  )

  const hasActiveStudentExportFilters =
    nameFilter.trim().length > 0 ||
    studentChartFilter !== null ||
    pctMin !== 0 ||
    pctMax !== 100 ||
    selectedQuestionCount < availableQuestions.length ||
    selectedStageCount < availableStages.length

  // Métricas pré-agregadas liberam KPIs sem esperar core/meta Firestore.
  // BootSymbol só quando ainda não há métricas NEM conteúdo local.
  const metricsPageReady =
    metricsScopeKey === selectedIdsKey &&
    activeInstitutionIds.length > 0 &&
    activeInstitutionIds.every((id) => metricsByInst.has(id))
  const isDashboardLoading =
    Boolean(selectedId || activeInstitutionIds.length > 0) &&
    !hasDashboardContent &&
    !metricsPageReady &&
    (loadingData || loadingMeta)
  const isDashboardRefreshing =
    (hasDashboardContent || metricsPageReady) &&
    dataScopeKey === selectedIdsKey &&
    !loadingMeta &&
    !loadingData &&
    isRefreshing

  useEffect(() => {
    if (isDashboardLoading || isDashboardRefreshing) return
    loadTargetPercentRef.current = 0
    if (selectedId && dashboardLoadStartedAtRef.current > 0) {
      const ms = Math.round(performance.now() - dashboardLoadStartedAtRef.current)
      dashboardLoadStartedAtRef.current = 0
      // Telemetria leve local (útil em staging / DevTools).
      console.info(
        `[dashboard] pronto em ${ms}ms (institution_id=${selectedId})`,
      )
    }
  }, [isDashboardLoading, isDashboardRefreshing, selectedId])

  useEffect(() => {
    if (!isDashboardLoading && !isDashboardRefreshing) return

    const id = window.setInterval(() => {
      const target = loadTargetPercentRef.current
      setLoadPercent((current) => {
        if (current === target) return current
        if (current < target) return Math.min(current + 1, target)
        return Math.max(current - 1, target)
      })
    }, 40)

    return () => window.clearInterval(id)
  }, [isDashboardLoading, isDashboardRefreshing, loadStepsDone, loadStepsTotal])

  const institutionOptions = sortedInstitutions.map((inst) => ({
    id: inst.id,
    label: inst.name || inst.id,
  }))

  const questionPickerItems = availableQuestions.map((n) => ({
    id: String(n),
    label: `Atividade ${n}`,
  }))
  const questionPickerSelectedIds = availableQuestions
    .filter((n) => !deselectedQuestions.has(n))
    .map(String)
  const questionPickerLabel =
    availableQuestions.length > 0
      ? ` (${selectedQuestionCount}/${availableQuestions.length})`
      : ''

  const stagePickerItems = availableStages.map((s) => ({
    id: s.key,
    label: `${s.trailName} · Etapa ${s.stageNumber}${
      s.title ? ` - ${s.title}` : ''
    } (${s.stageType === 'exercise' ? 'Exercício' : 'Conteúdo'})`,
  }))
  const stagePickerSelectedIds = availableStages
    .map((s) => s.key)
    .filter((k) => !deselectedStages.has(k))
  const stagePickerLabel =
    availableStages.length > 0
      ? ` (${selectedStageCount}/${availableStages.length})`
      : ''

  const columnPickerItems = ALL_STUDENT_COLUMNS.map((c) => ({
    id: c.key,
    label: c.label,
  }))
  const columnPickerSelectedIds = ALL_STUDENT_COLUMNS.map((c) => c.key).filter(
    (k) => !hiddenColumns.has(k),
  )

  const studentExportTrails = relevantTrails.map((trail) => ({
    id: trail.id,
    label: trail.name || trail.id,
  }))

  const pillExportTrailOptions = pillExportTrails.map((trail) => ({
    id: trail.id,
    label: trail.name || trail.id,
  }))

  const toPillView = (p: PillRow): DashboardPillRowView => ({
    ...p,
    trailHref: trailPath(p.trailId),
  })

  const paginatedStudentRowsView = paginatedStudentRows.map((row) => ({
    id: row.student.id,
    name: row.student.name,
    href: studentPath(row.student.id),
    phone: row.student.phone_number || '',
    released: row.released,
    done: row.done,
    completionPct: row.completionPct,
    lessonsReleased: row.lessonsReleased,
    lessonsDone: row.lessonsDone,
    lessonsCompletionPct: row.lessonsCompletionPct,
    correct: row.correct,
    wrong: row.wrong,
    accuracyPct: row.accuracyPct,
  }))

  const visibleColumnsView = visibleColumns.map((c) => ({
    key: c.key,
    label: c.label,
    sortIndicator: studentSortIndicator(c.key),
  }))

  const agentUsageView = (() => {
    const agents = agentUsage.agents.map((agent) => ({
      trailId: agent.trailId,
      trailIds: agent.trailIds?.length ? agent.trailIds : [agent.trailId],
      label: agent.label,
      messages: agent.messages,
      uniqueStudents: agent.uniqueStudents,
      pctOfTotal: agent.pctOfTotal,
      lastActivityLabel: formatAgentLastActivity(agent.lastActivity),
      studentIds: agent.studentIds,
    }))
    // Prefer IDs; se compact (sem student_ids), usa uniqueStudents do agregado/agentes.
    const fromIds = new Set(agents.flatMap((a) => a.studentIds))
    const uniqueStudents =
      fromIds.size > 0
        ? fromIds.size
        : typeof agentUsage.uniqueStudents === 'number' &&
            agentUsage.uniqueStudents > 0
          ? agentUsage.uniqueStudents
          : agents.reduce((n, a) => n + (a.uniqueStudents || 0), 0)
    const activeTutorCount = agents.filter((a) => a.messages > 0).length
    const activeDayCount = new Set(agentUsage.series.map((p) => p.date)).size
    const coveragePct =
      studentRows.length > 0
        ? Math.round((uniqueStudents / studentRows.length) * 1000) / 10
        : 0
    return {
      totalMessages: agentUsage.totalMessages,
      uniqueStudents,
      coveragePct,
      msgsPerTutorPerDay: messagesPerTutorPerDay({
        totalMessages: agentUsage.totalMessages,
        activeTutorCount,
        periodDays: agentPeriodDays,
        activeDayCount,
        seriesDates: agentUsage.series.map((point) => point.date),
        lastActivityDates: agentUsage.agents.map((a) => a.lastActivity),
      }),
      agents,
      series: agentUsage.series.map((point) => {
        const agent = agents.find((a) => a.trailId === point.trailId)
        return {
          date: point.date,
          trailId: point.trailId,
          label: agent?.label ?? point.trailId,
          messages: point.messages,
        }
      }),
    }
  })()

  const selectedAgentStudents = (() => {
    if (!selectedAgentTrailId) return []
    const row = agentUsage.agents.find((a) => a.trailId === selectedAgentTrailId)
    if (!row) return []
    const byId = new Map(students.map((s) => [s.id, s]))
    const trailIds = row.trailIds?.length ? row.trailIds : [row.trailId]
    const statsById = new Map(
      (row.studentStats ?? []).map((st) => [st.studentId, st]),
    )
    const ids =
      row.studentStats?.length > 0
        ? row.studentStats.map((st) => st.studentId)
        : row.studentIds
    return ids.map((id) => {
      const student = byId.get(id)
      const st = statsById.get(id)
      return {
        id,
        name: student?.name?.trim() || id,
        href: studentPath(id, {
          agentTrailId: row.trailId,
          agentTrailIds: trailIds,
        }),
        messages: st?.messages ?? 0,
        lastActivityLabel: formatAgentLastActivity(st?.lastActivity ?? null),
      }
    })
  })()

  /** Exportar histórico (1.1.3): CSV da tabela de exercícios como está na tela, sem paginação. */
  function exportExerciseHistory() {
    const rows = sortedPillRows.map((r) => [
      r.trailName,
      String(r.questionNumber),
      r.exerciseLabel,
      `${r.accuracyPct}%`,
      String(r.total),
      String(r.correct),
      String(r.wrong),
      r.gabarito || 'N/A',
    ])
    downloadText(
      `historico-exercicios-${selectedId ?? 'instituicao'}.csv`,
      toCsv(['Trilha', 'Atividade', 'Título', '% de acerto', 'Respostas', 'Acertos', 'Erros', 'Gabarito'], rows),
    )
  }

  return (
    <DashboardPageView
      studentFilterOptions={studentRows.map((r) => ({ id: r.student.id, label: r.student.name || r.student.id }))}
      studentFilterSelectedIds={studentRows.filter((r) => !studentPick || studentPick.has(r.student.id)).map((r) => r.student.id)}
      onStudentFilterChange={(ids) => {
        setStudentPick(ids.size === studentRows.length ? null : new Set(ids))
        setStudentPage(1)
      }}
      institutionName={
        activeInstitutionIds.length > 1
          ? `${activeInstitutionIds.length} instituições`
          : institutionOptions.find((o) => o.id === selectedId)?.label ?? 'N/A'
      }
      trailFilterOptions={allActiveTrails.map((t) => ({ id: t.id, label: t.name || t.id }))}
      trailFilterSelectedIds={activeTrails.map((t) => t.id)}
      onTrailFilterChange={(ids) => {
        setTrailFilter(ids.size === allActiveTrails.length ? null : new Set(ids))
        setPillPage(1)
        setStudentPage(1)
      }}
      onExportExerciseHistory={exportExerciseHistory}
      loadingInst={loadingInst}
      institutionOptions={institutionOptions}
      selectedId={
        gestao.selectedIds.size === 1
          ? ([...gestao.selectedIds][0] ?? selectedId)
          : gestao.selectedIds.size > 1
            ? ''
            : selectedId
      }
      onSelectInstitution={(id) => {
        if (!id) return
        selectInstitution(id)
        setStudentChartFilter(null)
        setActiveTab('students')
        setQuestionsDataEnabled(false)
        // Mantém agentPeriodDays (Todo/7d/30d) entre instituições.
        setSelectedAgentTrailId(null)
        setPillSearch('')
        setPillTrailFilter('')
        setPillMinResponses(1)
        setPillAccMin(0)
        setPillAccMax(100)
        setPillPage(1)
      }}
      activeTab={activeTab}
      onActiveTabChange={(tab) => {
        setActiveTab(tab)
        if (tab === 'questions' && !questionsDataEnabled) {
          startQuestionsTransition(() => {
            setQuestionsDataEnabled(true)
          })
        }
      }}
      isQuestionsTabLoading={
        activeTab === 'questions' &&
        (!questionsDataEnabled || isQuestionsPending)
      }
      instError={instError}
      dataError={dataError}
      exportError={exportError}
      isDashboardLoading={isDashboardLoading}
      isDashboardRefreshing={isDashboardRefreshing}
      loadLabel={loadLabel}
      loadPercent={loadPercent}
      logsError={logsError}
      onRetryLogs={() => {
        // Reabre o gate no retry após falha (erro + tentar de novo, nunca 0 silencioso).
        initialLogsLoadedRef.current = false
        setLogsFailed(false)
        setLogsError(null)
        setLoadingLogs(true)
        setAgentUsageLoading(true)
        setLogsRetryKey((k) => k + 1)
      }}
      agentUsageLoading={
        agentUsageLoading ||
        agentScopeKey !== `${selectedIdsKey}|${agentPeriodDays}`
      }
      summary={summary}
      exercisesLoading={
        !(
          metricsScopeKey === selectedIdsKey &&
          activeInstitutionIds.every((id) => metricsByInst.has(id))
        ) &&
        dashboardAccuracyGate({
          selectedIdsKey,
          selectedIds: activeInstitutionIds,
          dataScopeKey,
          loadingData,
          metaReady:
            !loadingMeta && questions.length > 0 && stages.length > 0,
          logsReadyIds,
          loadingLogs,
          logsFailed,
        }).exercisesLoading
      }
      missingGabaritoCount={missingGabaritoCount}
      annulledGabaritoCount={annulledGabaritoCount}
      annulledAnswersExcluded={annulledAnswersExcluded}
      filteredStudentCount={chartFilteredStudentRows.length}
      totalStudentCount={
        summary.countsLoading
          ? 0
          : studentRows.length > 0
            ? studentRows.length
            : (summary.activeStudents ?? 0)
      }
      studentsCountLoading={
        summary.countsLoading ||
        (studentRows.length === 0 && (loadingData || !hasDashboardContent))
      }
      questionPickerLabel={questionPickerLabel}
      showQuestionPicker={showQuestionPicker}
      onToggleQuestionPicker={() => {
        setShowQuestionPicker((v) => !v)
        setShowStagePicker(false)
        setShowColumnPicker(false)
      }}
      questionPickerItems={questionPickerItems}
      questionPickerSelectedIds={questionPickerSelectedIds}
      onApplyQuestionPicker={(next) => {
        setDeselectedQuestions(
          new Set(availableQuestions.filter((n) => !next.has(String(n)))),
        )
        setShowQuestionPicker(false)
      }}
      onCloseQuestionPicker={() => setShowQuestionPicker(false)}
      stagePickerLabel={stagePickerLabel}
      showStagePicker={showStagePicker}
      onToggleStagePicker={() => {
        setShowStagePicker((v) => !v)
        setShowQuestionPicker(false)
        setShowColumnPicker(false)
      }}
      stagePickerItems={stagePickerItems}
      stagePickerSelectedIds={stagePickerSelectedIds}
      onApplyStagePicker={(next) => {
        setDeselectedStages(
          new Set(
            availableStages.map((s) => s.key).filter((k) => !next.has(k)),
          ),
        )
        setShowStagePicker(false)
      }}
      onCloseStagePicker={() => setShowStagePicker(false)}
      showColumnPicker={showColumnPicker}
      onToggleColumnPicker={() => {
        setShowColumnPicker((v) => !v)
        setShowStagePicker(false)
        setShowQuestionPicker(false)
      }}
      columnPickerItems={columnPickerItems}
      columnPickerSelectedIds={columnPickerSelectedIds}
      onApplyColumnPicker={(next) => {
        setHiddenColumns(
          new Set(
            ALL_STUDENT_COLUMNS.map((c) => c.key).filter((k) => !next.has(k)),
          ),
        )
        setShowColumnPicker(false)
      }}
      onCloseColumnPicker={() => setShowColumnPicker(false)}
      studentExportTrails={studentExportTrails}
      exportingTrailId={exportingTrailId}
      onExportTrailHistory={(trailId) => {
        void exportTrailHistoryXlsx(trailId)
      }}
      hasActiveStudentExportFilters={hasActiveStudentExportFilters}
      nameFilter={nameFilter}
      onNameFilterChange={setNameFilter}
      pctMin={pctMin}
      pctMax={pctMax}
      onPctMinChange={setPctMin}
      onPctMaxChange={setPctMax}
      nameSortIndicator={studentSortIndicator('name')}
      onToggleStudentSort={toggleStudentSort}
      visibleColumns={visibleColumnsView}
      studentRowsEmpty={studentRows.length === 0}
      paginatedStudentRows={paginatedStudentRowsView}
      showStudentPagination={
        sortedFilteredStudentRows.length > STUDENTS_PAGE_SIZE
      }
      studentPageRange={studentPageRange}
      sortedFilteredStudentCount={sortedFilteredStudentRows.length}
      studentPage={studentPage}
      studentPageCount={studentPageCount}
      onStudentPagePrev={() => setStudentPage((p) => Math.max(1, p - 1))}
      onStudentPageNext={() =>
        setStudentPage((p) => Math.min(studentPageCount, p + 1))
      }
      studentsCharts={studentsCharts}
      studentChartFilter={studentChartFilter}
      onStudentChartFilterChange={setStudentChartFilter}
      sortedPillCount={sortedPillRows.length}
      totalPillCount={pillRows.length}
      pillExportTrails={pillExportTrailOptions}
      exportingPillTrailId={exportingPillTrailId}
      onExportPillTrail={(trailId) => {
        void exportPillTrailXlsx(trailId)
      }}
      pillSearch={pillSearch}
      onPillSearchChange={setPillSearch}
      pillTrailFilter={pillTrailFilter}
      onPillTrailFilterChange={setPillTrailFilter}
      pillTrailOptions={pillTrailOptions}
      pillMinResponses={pillMinResponses}
      onPillMinResponsesChange={setPillMinResponses}
      pillAccMin={pillAccMin}
      pillAccMax={pillAccMax}
      onPillAccMinChange={setPillAccMin}
      onPillAccMaxChange={setPillAccMax}
      questionsCharts={questionsCharts}
      worstPills={worstPills.map(toPillView)}
      bestPills={bestPills.map(toPillView)}
      onTogglePillSort={togglePillSort}
      pillSortIndicator={pillSortIndicator}
      paginatedPillRows={paginatedPillRows.map(toPillView)}
      showPillPagination={sortedPillRows.length > PILLS_PAGE_SIZE}
      pillPageRange={pillPageRange}
      pillPage={pillPage}
      pillPageCount={pillPageCount}
      onPillPagePrev={() => setPillPage((p) => Math.max(1, p - 1))}
      onPillPageNext={() =>
        setPillPage((p) => Math.min(pillPageCount, p + 1))
      }
      agentUsage={agentUsageView}
      agentPeriodDays={agentPeriodDays}
      onAgentPeriodDaysChange={(days) => {
        setAgentPeriodDaysPersist(days)
        setSelectedAgentTrailId(null)
      }}
      agentUsageUnavailable={!agentUsagePresent}
      metricsUpdatedAtLabel={metricsUpdatedAtLabel}
      onForceRefreshMetrics={forceRefreshMetrics}
      metricsForceRefreshing={metricsForceRefreshing}
      selectedAgentTrailId={selectedAgentTrailId}
      onSelectAgentTrailId={setSelectedAgentTrailId}
      selectedAgentStudents={selectedAgentStudents}
    />
  )
}
