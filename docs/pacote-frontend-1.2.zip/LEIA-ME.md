# Pacote frontend 1.2 (antes 1.1.1.b)

Base: o `main` do sócio em `4fbe81e` (já mesclado no nosso GitHub, commit `28c46c8`). Este pacote traz só o que mudou depois disso.

## Como aplicar
1. Copie `arquivos/` por cima da raiz do repositório, mantendo as pastas.
2. **Apague** os arquivos listados em `APAGAR.txt`.
3. Leia `LEIA-ME-CURSOR.md` (regra de login por telefone ou e-mail, campos novos do banco, o que o backend ainda precisa fazer).
4. Rode `npm run typecheck && npx vitest run && npm run build`.
5. Faça o deploy das regras do Firestore (`firestore.rules` ganhou `admin_profiles`).

`pacote-1.2.patch` é o mesmo conteúdo em formato de diff (sem imagens e sem os protótipos HTML).

## Alertas principais (CURSOR)
- **Login por telefone OU e-mail** (aluno e Educação), com escolha de qual vale para a senha (`login_identifier`): código em `frontend/crias-gestao/src/lib/loginRule.ts`. O backend ainda precisa respeitar isso e permitir login da Educação por telefone.
- **Campos novos:** `students.email`, `students.login_identifier`, `admin_users.name/phone_number/login_identifier`, coleção `admin_profiles`, ID `tel_<dígitos>` em `admin_users`.
- `api/student.ts` (e-mail e telefone opcionais, `login_identifier`) e `server/lib/studentPanelService.ts` (Painel do aluno: lista completa de erros e e-mail/login do aluno).
- Senha de aluno gerada na tela agora grava pelo Salvar do topo (`updateStudentPassword`): conferir a auditoria que a rota `regenerate` fazia.
- `npm test` completo tem 3 falhas que já existiam (`check-design-boundaries`).

## O que entrou
Dados redesenhado (filtros fixos, resumo, pizza, filtro por % de conclusão, Desempenho, seletores de Atividades e Etapas, vocabulário nas planilhas); Nova trilha com Prévia em colunas e recolhimento pela rolagem; Aluno com trilhas vinculadas pendentes até o Salvar do topo; tela cheia (Aluno e Educação); menu da Educação no topo com logo Crias | Educação; Perfil (Educação e Aluno); Usuários unificado e perfis editáveis; Salvar e Cancelar só com alteração pendente, com pop-ups padronizados e aviso ao sair; 8 ações em massa com painel único (confirmação em linha, resultado com erros); Nova trilha em 3 etapas (nasce ativa); página da Instituição; Conteúdo com "Novas atividades"; Alunos e Trilhas com as colunas e filtros do design; Painel do aluno em dashboard (Mais erros e Mais acertos), barra do monitor leva à Monitoria; menu do aluno recolhe as outras trilhas.

## Ainda não aplicado
- Perfis personalizados com nome ("+ Adicionar perfil"): só Admin e Básico são editáveis (precisa de campo de perfil no usuário).
- Dados: os cartões e o filtro seguem o desenho; os baldes de "Conclusão das atividades" continuam em 5 faixas (a lógica do sócio não foi alterada).
- Conferir em tablet real: tela cheia e as telas do Aluno.
