# Prompt para o Claude Code: aplicar o pacote 1.1.1.b do Crias

Cole o texto abaixo no Claude Code, na raiz do repositório thiagocrias/crias-web (branch main), depois de copiar o conteúdo de `export/repo/` por cima da raiz.

---

Você vai aplicar o pacote **1.1.1.b** do redesign do Crias nos apps `frontend/crias-aluno` e `frontend/crias-gestao` (exibido como **Crias Educação**). Junte com o pacote 1.1.1.a para formar a v1.1.1.

**Fonte de verdade**
- `frontend/crias-aluno/design/INTERFACE.md`, seção **"Pacote 1.1.1.b: regras consolidadas"**. Ela vale sobre todas as outras seções. O histórico abaixo dela serve para detalhe; se houver diferença, vale a consolidada.
- Protótipos: `frontend/crias-aluno/design/prototipo/Crias Aluno.dc.html` e `Crias Gestao.dc.html` (ou as versões `offline.html`). Abra no navegador e compare tela a tela, na web, no celular (tweak "celular") e no tablet retrato e paisagem (tweak "tablet").
- Revisões mais recentes: INTERFACE.md, "Revisão 8" (logo alinhado ao Voltar, favicon, Salvar no topo para toda alteração, etapas da nova trilha, Prévia, Dados, Usuários, Senhas, Instituição).
- `CLAUDE.md` na raiz: vocabulário, cores e regras gerais.

**Escopo**
1. Só camada visual: estilos, JSX de apresentação, textos e estados de botões. Não mude contratos de API, modelos ou regras de negócio.
2. Onde a tela precisar de dado ou endpoint que ainda não existe, use dados mockados isolados e marque `// TODO backend 1.1.1.b: <item>`. Itens marcados como CONFLITO em INTERFACE.md param e pedem aval.
3. Não aplique os itens de "Pontos para validação" (seção I) sem aval.

**Ordem sugerida**
1. Tokens e componentes base (seção B): os sete tipos de botão, Voltar único, cabeçalho fixo com esmaecimento progressivo, abas segmentadas, tabelas, setas de recolher bege.
2. Confirmações (seção C): um componente de pop-up com as variantes neutro / ação / destrutivo, o pop-up de exclusão com DELETAR e a confirmação em linha. Use os textos exatos da tabela.
3. Ações em massa (seção D): um componente de painel com a sequência baixar → carregar → ação → confirmação em linha → resultado.
4. Salvar, cancelar e sair (seção E).
5. Logo e nome Crias Educação (`crias-logo-educacao.svg` e `-branco`, 150×22).
6. Páginas da Educação (seção F) e do Aluno (seção G), depois celular (seção H).
7. Revisão de textos: português do Brasil, sem travessão, "etapa" e "exercício", nunca "passo" nem "bloco", "em massa" (nunca "em lote"), "N/A" para dado ausente.

**Entrega**
- Commits pequenos por área, mensagem em português.
- Ao final, gere `frontend/crias-aluno/design/RELATORIO-1.1.1.b.md` com o que foi aplicado, os TODOs de backend e as diferenças que ficaram em relação ao protótipo.
- Não apague versões anteriores nem arquivos de `design/`.
